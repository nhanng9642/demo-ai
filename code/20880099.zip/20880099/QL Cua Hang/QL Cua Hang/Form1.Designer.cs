﻿
namespace QL_Cua_Hang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTenHang = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtHanDung = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.txtCongtysanxuat = new System.Windows.Forms.TextBox();
            this.txtNamsanxuat = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBoxLH = new System.Windows.Forms.ComboBox();
            this.dataGridViewKho = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.txtLoaiHang1 = new System.Windows.Forms.TextBox();
            this.txtCongtysanxuat1 = new System.Windows.Forms.TextBox();
            this.txtMa1 = new System.Windows.Forms.TextBox();
            this.txtNamsanxuat1 = new System.Windows.Forms.TextBox();
            this.txtHanDung1 = new System.Windows.Forms.TextBox();
            this.txtTenHang1 = new System.Windows.Forms.TextBox();
            this.dataGridViewTimkiem = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTenLoaiHang = new System.Windows.Forms.TextBox();
            this.dataGridViewLoaiHang = new System.Windows.Forms.DataGridView();
            this.Maloaihang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LoaiHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtMaLoaiHang = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSuaLH = new System.Windows.Forms.Button();
            this.btnXoaLH = new System.Windows.Forms.Button();
            this.btnThemLH = new System.Windows.Forms.Button();
            this.MaSP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKho)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTimkiem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLoaiHang)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Sản Phẩm";
            // 
            // txtMa
            // 
            this.txtMa.Location = new System.Drawing.Point(179, 36);
            this.txtMa.Name = "txtMa";
            this.txtMa.Size = new System.Drawing.Size(100, 20);
            this.txtMa.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên Hàng";
            // 
            // txtTenHang
            // 
            this.txtTenHang.Location = new System.Drawing.Point(179, 76);
            this.txtTenHang.Name = "txtTenHang";
            this.txtTenHang.Size = new System.Drawing.Size(100, 20);
            this.txtTenHang.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Hạn Dùng";
            // 
            // txtHanDung
            // 
            this.txtHanDung.Location = new System.Drawing.Point(179, 124);
            this.txtHanDung.Name = "txtHanDung";
            this.txtHanDung.Size = new System.Drawing.Size(100, 20);
            this.txtHanDung.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Công ty sản xuất";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Năm sản xuất";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Loại Hàng";
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(38, 342);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 23);
            this.btnThem.TabIndex = 4;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(139, 342);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 23);
            this.btnXoa.TabIndex = 4;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(241, 342);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 23);
            this.btnSua.TabIndex = 4;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.Location = new System.Drawing.Point(106, 335);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(75, 23);
            this.btnTimKiem.TabIndex = 4;
            this.btnTimKiem.Text = "Tìm kiếm";
            this.btnTimKiem.UseVisualStyleBackColor = true;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // txtCongtysanxuat
            // 
            this.txtCongtysanxuat.Location = new System.Drawing.Point(179, 172);
            this.txtCongtysanxuat.Name = "txtCongtysanxuat";
            this.txtCongtysanxuat.Size = new System.Drawing.Size(100, 20);
            this.txtCongtysanxuat.TabIndex = 1;
            // 
            // txtNamsanxuat
            // 
            this.txtNamsanxuat.Location = new System.Drawing.Point(179, 219);
            this.txtNamsanxuat.Name = "txtNamsanxuat";
            this.txtNamsanxuat.Size = new System.Drawing.Size(100, 20);
            this.txtNamsanxuat.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.comboBoxLH);
            this.panel1.Controls.Add(this.btnThem);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnSua);
            this.panel1.Controls.Add(this.txtMa);
            this.panel1.Controls.Add(this.btnXoa);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtTenHang);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtHanDung);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtNamsanxuat);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtCongtysanxuat);
            this.panel1.Location = new System.Drawing.Point(5, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(352, 418);
            this.panel1.TabIndex = 5;
            // 
            // comboBoxLH
            // 
            this.comboBoxLH.FormattingEnabled = true;
            this.comboBoxLH.Location = new System.Drawing.Point(179, 262);
            this.comboBoxLH.Name = "comboBoxLH";
            this.comboBoxLH.Size = new System.Drawing.Size(100, 21);
            this.comboBoxLH.TabIndex = 5;
            // 
            // dataGridViewKho
            // 
            this.dataGridViewKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewKho.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridViewKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaSP,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dataGridViewKho.Location = new System.Drawing.Point(12, 471);
            this.dataGridViewKho.Name = "dataGridViewKho";
            this.dataGridViewKho.ReadOnly = true;
            this.dataGridViewKho.Size = new System.Drawing.Size(345, 187);
            this.dataGridViewKho.TabIndex = 6;
            this.dataGridViewKho.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewKho_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel2.Controls.Add(this.checkBox6);
            this.panel2.Controls.Add(this.checkBox5);
            this.panel2.Controls.Add(this.checkBox3);
            this.panel2.Controls.Add(this.checkBox4);
            this.panel2.Controls.Add(this.checkBox2);
            this.panel2.Controls.Add(this.checkBox1);
            this.panel2.Controls.Add(this.btnTimKiem);
            this.panel2.Controls.Add(this.txtLoaiHang1);
            this.panel2.Controls.Add(this.txtCongtysanxuat1);
            this.panel2.Controls.Add(this.txtMa1);
            this.panel2.Controls.Add(this.txtNamsanxuat1);
            this.panel2.Controls.Add(this.txtHanDung1);
            this.panel2.Controls.Add(this.txtTenHang1);
            this.panel2.Location = new System.Drawing.Point(375, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(326, 418);
            this.panel2.TabIndex = 7;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(27, 264);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(75, 17);
            this.checkBox6.TabIndex = 5;
            this.checkBox6.Text = "Loại Hàng";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(27, 218);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(91, 17);
            this.checkBox5.TabIndex = 5;
            this.checkBox5.Text = "Năm sản xuất";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(27, 123);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(75, 17);
            this.checkBox3.TabIndex = 5;
            this.checkBox3.Text = "Hạn Dùng";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(27, 171);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(105, 17);
            this.checkBox4.TabIndex = 5;
            this.checkBox4.Text = "Công ty sản xuất";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(27, 75);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(74, 17);
            this.checkBox2.TabIndex = 5;
            this.checkBox2.Text = "Tên Hàng";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(27, 35);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(41, 17);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "Mã";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // txtLoaiHang1
            // 
            this.txtLoaiHang1.Location = new System.Drawing.Point(172, 261);
            this.txtLoaiHang1.Name = "txtLoaiHang1";
            this.txtLoaiHang1.Size = new System.Drawing.Size(100, 20);
            this.txtLoaiHang1.TabIndex = 1;
            // 
            // txtCongtysanxuat1
            // 
            this.txtCongtysanxuat1.Location = new System.Drawing.Point(172, 168);
            this.txtCongtysanxuat1.Name = "txtCongtysanxuat1";
            this.txtCongtysanxuat1.Size = new System.Drawing.Size(100, 20);
            this.txtCongtysanxuat1.TabIndex = 1;
            // 
            // txtMa1
            // 
            this.txtMa1.Location = new System.Drawing.Point(172, 32);
            this.txtMa1.Name = "txtMa1";
            this.txtMa1.Size = new System.Drawing.Size(100, 20);
            this.txtMa1.TabIndex = 1;
            // 
            // txtNamsanxuat1
            // 
            this.txtNamsanxuat1.Location = new System.Drawing.Point(172, 215);
            this.txtNamsanxuat1.Name = "txtNamsanxuat1";
            this.txtNamsanxuat1.Size = new System.Drawing.Size(100, 20);
            this.txtNamsanxuat1.TabIndex = 1;
            // 
            // txtHanDung1
            // 
            this.txtHanDung1.Location = new System.Drawing.Point(172, 120);
            this.txtHanDung1.Name = "txtHanDung1";
            this.txtHanDung1.Size = new System.Drawing.Size(100, 20);
            this.txtHanDung1.TabIndex = 1;
            // 
            // txtTenHang1
            // 
            this.txtTenHang1.Location = new System.Drawing.Point(172, 72);
            this.txtTenHang1.Name = "txtTenHang1";
            this.txtTenHang1.Size = new System.Drawing.Size(100, 20);
            this.txtTenHang1.TabIndex = 1;
            // 
            // dataGridViewTimkiem
            // 
            this.dataGridViewTimkiem.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewTimkiem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTimkiem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12});
            this.dataGridViewTimkiem.Location = new System.Drawing.Point(375, 471);
            this.dataGridViewTimkiem.Name = "dataGridViewTimkiem";
            this.dataGridViewTimkiem.ReadOnly = true;
            this.dataGridViewTimkiem.Size = new System.Drawing.Size(326, 187);
            this.dataGridViewTimkiem.TabIndex = 8;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Mã Sản Phẩm";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Tên Hàng";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Hạn Dùng";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Công ty sản xuất";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Năm sản xuất";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Loại Hàng";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Tên Loại Hàng";
            // 
            // txtTenLoaiHang
            // 
            this.txtTenLoaiHang.Location = new System.Drawing.Point(113, 107);
            this.txtTenLoaiHang.Name = "txtTenLoaiHang";
            this.txtTenLoaiHang.Size = new System.Drawing.Size(100, 20);
            this.txtTenLoaiHang.TabIndex = 1;
            // 
            // dataGridViewLoaiHang
            // 
            this.dataGridViewLoaiHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewLoaiHang.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dataGridViewLoaiHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLoaiHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Maloaihang,
            this.LoaiHang});
            this.dataGridViewLoaiHang.Location = new System.Drawing.Point(722, 471);
            this.dataGridViewLoaiHang.Name = "dataGridViewLoaiHang";
            this.dataGridViewLoaiHang.ReadOnly = true;
            this.dataGridViewLoaiHang.Size = new System.Drawing.Size(235, 187);
            this.dataGridViewLoaiHang.TabIndex = 8;
            this.dataGridViewLoaiHang.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewLoaiHang_CellContentClick);
            // 
            // Maloaihang
            // 
            this.Maloaihang.DataPropertyName = "Maloaihang";
            this.Maloaihang.HeaderText = "Mã Loại Hàng";
            this.Maloaihang.Name = "Maloaihang";
            this.Maloaihang.ReadOnly = true;
            // 
            // LoaiHang
            // 
            this.LoaiHang.DataPropertyName = "LoaiHang";
            this.LoaiHang.HeaderText = "Loại Hàng";
            this.LoaiHang.Name = "LoaiHang";
            this.LoaiHang.ReadOnly = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Info;
            this.panel3.Controls.Add(this.txtMaLoaiHang);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.btnSuaLH);
            this.panel3.Controls.Add(this.btnXoaLH);
            this.panel3.Controls.Add(this.btnThemLH);
            this.panel3.Controls.Add(this.txtTenLoaiHang);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(722, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(236, 418);
            this.panel3.TabIndex = 9;
            // 
            // txtMaLoaiHang
            // 
            this.txtMaLoaiHang.Location = new System.Drawing.Point(113, 68);
            this.txtMaLoaiHang.Name = "txtMaLoaiHang";
            this.txtMaLoaiHang.Size = new System.Drawing.Size(99, 20);
            this.txtMaLoaiHang.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 72);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Mã Loại Hàng";
            // 
            // btnSuaLH
            // 
            this.btnSuaLH.Location = new System.Drawing.Point(76, 268);
            this.btnSuaLH.Name = "btnSuaLH";
            this.btnSuaLH.Size = new System.Drawing.Size(75, 23);
            this.btnSuaLH.TabIndex = 2;
            this.btnSuaLH.Text = "Sửa";
            this.btnSuaLH.UseVisualStyleBackColor = true;
            this.btnSuaLH.Click += new System.EventHandler(this.btnSuaLH_Click);
            // 
            // btnXoaLH
            // 
            this.btnXoaLH.Location = new System.Drawing.Point(76, 222);
            this.btnXoaLH.Name = "btnXoaLH";
            this.btnXoaLH.Size = new System.Drawing.Size(75, 23);
            this.btnXoaLH.TabIndex = 2;
            this.btnXoaLH.Text = "Xóa";
            this.btnXoaLH.UseVisualStyleBackColor = true;
            this.btnXoaLH.Click += new System.EventHandler(this.btnXoaLH_Click);
            // 
            // btnThemLH
            // 
            this.btnThemLH.Location = new System.Drawing.Point(76, 175);
            this.btnThemLH.Name = "btnThemLH";
            this.btnThemLH.Size = new System.Drawing.Size(75, 23);
            this.btnThemLH.TabIndex = 2;
            this.btnThemLH.Text = "Thêm";
            this.btnThemLH.UseVisualStyleBackColor = true;
            this.btnThemLH.Click += new System.EventHandler(this.btnThemLH_Click_1);
            // 
            // MaSP
            // 
            this.MaSP.DataPropertyName = "MaSP";
            this.MaSP.HeaderText = "Mã Sản Phẩm";
            this.MaSP.Name = "MaSP";
            this.MaSP.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Tên Hàng";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Hạn Dùng";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Công ty sản xuất";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Năm sản xuất";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Loại hàng";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(969, 668);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.dataGridViewLoaiHang);
            this.Controls.Add(this.dataGridViewTimkiem);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dataGridViewKho);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKho)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTimkiem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLoaiHang)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTenHang;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtHanDung;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.TextBox txtCongtysanxuat;
        private System.Windows.Forms.TextBox txtNamsanxuat;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txtLoaiHang1;
        private System.Windows.Forms.TextBox txtCongtysanxuat1;
        private System.Windows.Forms.TextBox txtMa1;
        private System.Windows.Forms.TextBox txtNamsanxuat1;
        private System.Windows.Forms.TextBox txtHanDung1;
        private System.Windows.Forms.TextBox txtTenHang1;
        private System.Windows.Forms.DataGridView dataGridViewTimkiem;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTenLoaiHang;
        private System.Windows.Forms.DataGridView dataGridViewLoaiHang;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnSuaLH;
        private System.Windows.Forms.Button btnXoaLH;
        private System.Windows.Forms.Button btnThemLH;
        protected System.Windows.Forms.ComboBox comboBoxLH;
        private System.Windows.Forms.TextBox txtMaLoaiHang;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Maloaihang;
        private System.Windows.Forms.DataGridViewTextBoxColumn LoaiHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaSP;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        protected System.Windows.Forms.DataGridView dataGridViewKho;
    }
}

