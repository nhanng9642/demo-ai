﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doan
{
    class SanPham
    {
        public string MaSanPham { get; set; }
        public string TenSanPham { get; set; }
        public string LoaiHang { get; set; }
        public string NhaSanXuat { get; set; }
        public DateTime HanDung { get; set; }
        public DateTime NamSanXuat { get; set; }

    }
}
