﻿namespace NMLT_QLCH_WindowsFormsApp
{
    public struct LoaiHang
    {
        public bool IsNullStruct;
        public string Id { get; set; }
        public string Ten { get; set; }
    }
}