﻿namespace PROJECT_NMLT
{
    partial class MH_SANPHAM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.t_timkiem = new System.Windows.Forms.TextBox();
            this.l_mahang = new System.Windows.Forms.Label();
            this.l_tenhang = new System.Windows.Forms.Label();
            this.l_handung = new System.Windows.Forms.Label();
            this.l_ctysanxuat = new System.Windows.Forms.Label();
            this.l_loaihang = new System.Windows.Forms.Label();
            this.l_namsanxuat = new System.Windows.Forms.Label();
            this.b_mhthem = new System.Windows.Forms.Button();
            this.b_timkiemg = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.b_suasanpham = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // t_timkiem
            // 
            this.t_timkiem.Location = new System.Drawing.Point(394, 28);
            this.t_timkiem.Name = "t_timkiem";
            this.t_timkiem.Size = new System.Drawing.Size(172, 20);
            this.t_timkiem.TabIndex = 1;
            // 
            // l_mahang
            // 
            this.l_mahang.AutoSize = true;
            this.l_mahang.Location = new System.Drawing.Point(25, 198);
            this.l_mahang.Name = "l_mahang";
            this.l_mahang.Size = new System.Drawing.Size(97, 13);
            this.l_mahang.TabIndex = 3;
            this.l_mahang.Text = "                              ";
            // 
            // l_tenhang
            // 
            this.l_tenhang.AutoSize = true;
            this.l_tenhang.Location = new System.Drawing.Point(160, 198);
            this.l_tenhang.Name = "l_tenhang";
            this.l_tenhang.Size = new System.Drawing.Size(70, 13);
            this.l_tenhang.TabIndex = 4;
            this.l_tenhang.Text = "                     ";
            // 
            // l_handung
            // 
            this.l_handung.AutoSize = true;
            this.l_handung.Location = new System.Drawing.Point(284, 198);
            this.l_handung.Name = "l_handung";
            this.l_handung.Size = new System.Drawing.Size(70, 13);
            this.l_handung.TabIndex = 5;
            this.l_handung.Text = "                     ";
            // 
            // l_ctysanxuat
            // 
            this.l_ctysanxuat.AutoSize = true;
            this.l_ctysanxuat.Location = new System.Drawing.Point(409, 207);
            this.l_ctysanxuat.Name = "l_ctysanxuat";
            this.l_ctysanxuat.Size = new System.Drawing.Size(58, 13);
            this.l_ctysanxuat.TabIndex = 6;
            this.l_ctysanxuat.Text = "                 ";
            // 
            // l_loaihang
            // 
            this.l_loaihang.AutoSize = true;
            this.l_loaihang.Location = new System.Drawing.Point(673, 207);
            this.l_loaihang.Name = "l_loaihang";
            this.l_loaihang.Size = new System.Drawing.Size(82, 13);
            this.l_loaihang.TabIndex = 13;
            this.l_loaihang.Text = "                         ";
            // 
            // l_namsanxuat
            // 
            this.l_namsanxuat.AutoSize = true;
            this.l_namsanxuat.Location = new System.Drawing.Point(530, 207);
            this.l_namsanxuat.Name = "l_namsanxuat";
            this.l_namsanxuat.Size = new System.Drawing.Size(76, 13);
            this.l_namsanxuat.TabIndex = 14;
            this.l_namsanxuat.Text = "                       ";
            // 
            // b_mhthem
            // 
            this.b_mhthem.Location = new System.Drawing.Point(46, 93);
            this.b_mhthem.Name = "b_mhthem";
            this.b_mhthem.Size = new System.Drawing.Size(111, 23);
            this.b_mhthem.TabIndex = 15;
            this.b_mhthem.Text = "Them San Pham";
            this.b_mhthem.UseVisualStyleBackColor = true;
            this.b_mhthem.Click += new System.EventHandler(this.b_mhthem_Click);
            // 
            // b_timkiemg
            // 
            this.b_timkiemg.Location = new System.Drawing.Point(304, 25);
            this.b_timkiemg.Name = "b_timkiemg";
            this.b_timkiemg.Size = new System.Drawing.Size(75, 23);
            this.b_timkiemg.TabIndex = 17;
            this.b_timkiemg.Text = "Tim Kiem";
            this.b_timkiemg.UseVisualStyleBackColor = true;
            this.b_timkiemg.Click += new System.EventHandler(this.b_timkiemg_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(63, 182);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(663, 199);
            this.dataGridView1.TabIndex = 18;
            // 
            // b_suasanpham
            // 
            this.b_suasanpham.Location = new System.Drawing.Point(236, 92);
            this.b_suasanpham.Name = "b_suasanpham";
            this.b_suasanpham.Size = new System.Drawing.Size(143, 23);
            this.b_suasanpham.TabIndex = 19;
            this.b_suasanpham.Text = "Sua San Pham";
            this.b_suasanpham.UseVisualStyleBackColor = true;
            this.b_suasanpham.Click += new System.EventHandler(this.b_suasanpham_Click);
            // 
            // MH_SANPHAM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.b_suasanpham);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.b_timkiemg);
            this.Controls.Add(this.b_mhthem);
            this.Controls.Add(this.l_namsanxuat);
            this.Controls.Add(this.l_loaihang);
            this.Controls.Add(this.l_ctysanxuat);
            this.Controls.Add(this.l_handung);
            this.Controls.Add(this.l_tenhang);
            this.Controls.Add(this.l_mahang);
            this.Controls.Add(this.t_timkiem);
            this.Name = "MH_SANPHAM";
            this.Text = "MH_SANPHAM";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox t_timkiem;
        private System.Windows.Forms.Label l_mahang;
        private System.Windows.Forms.Label l_tenhang;
        private System.Windows.Forms.Label l_handung;
        private System.Windows.Forms.Label l_ctysanxuat;
        private System.Windows.Forms.Label l_loaihang;
        private System.Windows.Forms.Label l_namsanxuat;
        private System.Windows.Forms.Button b_mhthem;
        private System.Windows.Forms.Button b_timkiemg;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button b_suasanpham;
    }
}