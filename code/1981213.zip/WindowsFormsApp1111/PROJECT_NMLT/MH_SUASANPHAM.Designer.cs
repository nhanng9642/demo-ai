﻿namespace PROJECT_NMLT
{
    partial class MH_SUASANPHAM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.l_mahang = new System.Windows.Forms.Label();
            this.l_tebhang = new System.Windows.Forms.Label();
            this.l_handung = new System.Windows.Forms.Label();
            this.l_ctysanxuat = new System.Windows.Forms.Label();
            this.l_namsanxuat = new System.Windows.Forms.Label();
            this.l_loaihang = new System.Windows.Forms.Label();
            this.t_mahang = new System.Windows.Forms.TextBox();
            this.t_tenhang = new System.Windows.Forms.TextBox();
            this.t_handung = new System.Windows.Forms.TextBox();
            this.t_ctysanxuat = new System.Windows.Forms.TextBox();
            this.t_namsanxuat = new System.Windows.Forms.TextBox();
            this.t_loaihang = new System.Windows.Forms.TextBox();
            this.b_suasanpham = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // l_mahang
            // 
            this.l_mahang.AutoSize = true;
            this.l_mahang.Location = new System.Drawing.Point(76, 57);
            this.l_mahang.Name = "l_mahang";
            this.l_mahang.Size = new System.Drawing.Size(51, 13);
            this.l_mahang.TabIndex = 1;
            this.l_mahang.Text = "Ma Hang";
            // 
            // l_tebhang
            // 
            this.l_tebhang.AutoSize = true;
            this.l_tebhang.Location = new System.Drawing.Point(75, 107);
            this.l_tebhang.Name = "l_tebhang";
            this.l_tebhang.Size = new System.Drawing.Size(55, 13);
            this.l_tebhang.TabIndex = 2;
            this.l_tebhang.Text = "Ten Hang";
            // 
            // l_handung
            // 
            this.l_handung.AutoSize = true;
            this.l_handung.Location = new System.Drawing.Point(75, 161);
            this.l_handung.Name = "l_handung";
            this.l_handung.Size = new System.Drawing.Size(56, 13);
            this.l_handung.TabIndex = 3;
            this.l_handung.Text = "Han Dung";
            // 
            // l_ctysanxuat
            // 
            this.l_ctysanxuat.AutoSize = true;
            this.l_ctysanxuat.Location = new System.Drawing.Point(78, 205);
            this.l_ctysanxuat.Name = "l_ctysanxuat";
            this.l_ctysanxuat.Size = new System.Drawing.Size(69, 13);
            this.l_ctysanxuat.TabIndex = 4;
            this.l_ctysanxuat.Text = "Cty San Xuat";
            // 
            // l_namsanxuat
            // 
            this.l_namsanxuat.AutoSize = true;
            this.l_namsanxuat.Location = new System.Drawing.Point(78, 257);
            this.l_namsanxuat.Name = "l_namsanxuat";
            this.l_namsanxuat.Size = new System.Drawing.Size(76, 13);
            this.l_namsanxuat.TabIndex = 5;
            this.l_namsanxuat.Text = "Nam San Xuat";
            // 
            // l_loaihang
            // 
            this.l_loaihang.AutoSize = true;
            this.l_loaihang.Location = new System.Drawing.Point(79, 306);
            this.l_loaihang.Name = "l_loaihang";
            this.l_loaihang.Size = new System.Drawing.Size(56, 13);
            this.l_loaihang.TabIndex = 6;
            this.l_loaihang.Text = "Loai Hang";
            // 
            // t_mahang
            // 
            this.t_mahang.Location = new System.Drawing.Point(169, 50);
            this.t_mahang.Name = "t_mahang";
            this.t_mahang.Size = new System.Drawing.Size(100, 20);
            this.t_mahang.TabIndex = 7;
            // 
            // t_tenhang
            // 
            this.t_tenhang.Location = new System.Drawing.Point(169, 100);
            this.t_tenhang.Name = "t_tenhang";
            this.t_tenhang.Size = new System.Drawing.Size(100, 20);
            this.t_tenhang.TabIndex = 8;
            // 
            // t_handung
            // 
            this.t_handung.Location = new System.Drawing.Point(169, 154);
            this.t_handung.Name = "t_handung";
            this.t_handung.Size = new System.Drawing.Size(100, 20);
            this.t_handung.TabIndex = 9;
            // 
            // t_ctysanxuat
            // 
            this.t_ctysanxuat.Location = new System.Drawing.Point(169, 198);
            this.t_ctysanxuat.Name = "t_ctysanxuat";
            this.t_ctysanxuat.Size = new System.Drawing.Size(100, 20);
            this.t_ctysanxuat.TabIndex = 10;
            // 
            // t_namsanxuat
            // 
            this.t_namsanxuat.Location = new System.Drawing.Point(169, 250);
            this.t_namsanxuat.Name = "t_namsanxuat";
            this.t_namsanxuat.Size = new System.Drawing.Size(100, 20);
            this.t_namsanxuat.TabIndex = 11;
            // 
            // t_loaihang
            // 
            this.t_loaihang.Location = new System.Drawing.Point(169, 299);
            this.t_loaihang.Name = "t_loaihang";
            this.t_loaihang.Size = new System.Drawing.Size(100, 20);
            this.t_loaihang.TabIndex = 12;
            // 
            // b_suasanpham
            // 
            this.b_suasanpham.Location = new System.Drawing.Point(303, 363);
            this.b_suasanpham.Name = "b_suasanpham";
            this.b_suasanpham.Size = new System.Drawing.Size(75, 23);
            this.b_suasanpham.TabIndex = 13;
            this.b_suasanpham.Text = "Sua";
            this.b_suasanpham.UseVisualStyleBackColor = true;
            this.b_suasanpham.Click += new System.EventHandler(this.b_suasanpham_Click);
            // 
            // MH_SUASANPHAM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.b_suasanpham);
            this.Controls.Add(this.t_loaihang);
            this.Controls.Add(this.t_namsanxuat);
            this.Controls.Add(this.t_ctysanxuat);
            this.Controls.Add(this.t_handung);
            this.Controls.Add(this.t_tenhang);
            this.Controls.Add(this.t_mahang);
            this.Controls.Add(this.l_loaihang);
            this.Controls.Add(this.l_namsanxuat);
            this.Controls.Add(this.l_ctysanxuat);
            this.Controls.Add(this.l_handung);
            this.Controls.Add(this.l_tebhang);
            this.Controls.Add(this.l_mahang);
            this.Name = "MH_SUASANPHAM";
            this.Text = "MH_THEM";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label l_mahang;
        private System.Windows.Forms.Label l_tebhang;
        private System.Windows.Forms.Label l_handung;
        private System.Windows.Forms.Label l_ctysanxuat;
        private System.Windows.Forms.Label l_namsanxuat;
        private System.Windows.Forms.Label l_loaihang;
        private System.Windows.Forms.TextBox t_mahang;
        private System.Windows.Forms.TextBox t_tenhang;
        private System.Windows.Forms.TextBox t_handung;
        private System.Windows.Forms.TextBox t_ctysanxuat;
        private System.Windows.Forms.TextBox t_namsanxuat;
        private System.Windows.Forms.TextBox t_loaihang;
        private System.Windows.Forms.Button b_suasanpham;
    }
}