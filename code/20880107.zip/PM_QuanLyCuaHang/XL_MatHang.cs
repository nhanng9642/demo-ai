﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_QuanLyCuaHang
{
    struct MatHang
    {
        public int MaHang;
        public string TenMatHang;
        public string LoaiHang;
        public string Congty;
        public int NamSX;
        public int HanDung;
    }
    class XL_MatHang
    {

    }
}
