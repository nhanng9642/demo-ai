﻿/*
 * Đồ án: Nhập môn lập trình
 * Mã môn: CTT003 
 * MSSV: 20810003
 * */
namespace QuanLyCuaHang
{
    class ProductType
    {
        /// <summary>
        /// Mã định danh duy nhất
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Tên loại hàng
        /// </summary>
        public string Name { get; set; }
    }
}
