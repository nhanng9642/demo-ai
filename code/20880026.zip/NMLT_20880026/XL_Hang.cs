﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NMLT_20880026
{
    struct Hang
    {
        public string mahang;
        public string tenhang;
        public string hsd;
        public string ctsx;
        public string namsx;
        public string loaihang;
    }
    class XL_Hang
    {
    }
}
