﻿namespace PhanMemQuanLyCuaHang
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridViewKhohang = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbxLoaiHang = new System.Windows.Forms.ComboBox();
            this.dateTimePicker_HanDung_KhoH = new System.Windows.Forms.DateTimePicker();
            this.btnNhapLai = new System.Windows.Forms.Button();
            this.txtDongia = new System.Windows.Forms.TextBox();
            this.txtSoluong = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnCapnhat = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.txtNamSX = new System.Windows.Forms.TextBox();
            this.txtCtySX = new System.Windows.Forms.TextBox();
            this.txtTenhang = new System.Windows.Forms.TextBox();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridViewTimKiem = new System.Windows.Forms.DataGridView();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.dateTimePickerTimDen = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_TimTu = new System.Windows.Forms.DateTimePicker();
            this.btnNhapTimKiem_Again = new System.Windows.Forms.Button();
            this.btnXoaTimKiem = new System.Windows.Forms.Button();
            this.txtTimLoaiHang = new System.Windows.Forms.TextBox();
            this.txtTimNamSX = new System.Windows.Forms.TextBox();
            this.txtTimCty = new System.Windows.Forms.TextBox();
            this.txtTimTenHang = new System.Windows.Forms.TextBox();
            this.txtTimMa = new System.Windows.Forms.TextBox();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.chkBoxLoaiHang = new System.Windows.Forms.CheckBox();
            this.chkBoxNamSX = new System.Windows.Forms.CheckBox();
            this.chkBoxCty = new System.Windows.Forms.CheckBox();
            this.chkBoxHanDung = new System.Windows.Forms.CheckBox();
            this.chkBoxTenhang = new System.Windows.Forms.CheckBox();
            this.chkBoxMa = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridViewXuatBan = new System.Windows.Forms.DataGridView();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dateTimePicker_NgayBan_XB = new System.Windows.Forms.DateTimePicker();
            this.btnXuatBan = new System.Windows.Forms.Button();
            this.txtGiaBan = new System.Windows.Forms.TextBox();
            this.txtSoluongBan = new System.Windows.Forms.TextBox();
            this.txtMahangBan = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridViewHangBan_LK = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_Xoa_BangLK = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.dateTimePickerBanDenNgay_LK = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker_BanTuNgay_LK = new System.Windows.Forms.DateTimePicker();
            this.chkBox_NgayBan_LK = new System.Windows.Forms.CheckBox();
            this.txtMaHangLKBan = new System.Windows.Forms.TextBox();
            this.chkBoxMaHangBan_LK = new System.Windows.Forms.CheckBox();
            this.btnLietKeHangBan = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKhohang)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTimKiem)).BeginInit();
            this.panel2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewXuatBan)).BeginInit();
            this.panel3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHangBan_LK)).BeginInit();
            this.panel4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(12, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(758, 411);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Peru;
            this.tabPage1.Controls.Add(this.dataGridViewKhohang);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(750, 385);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Kho hàng";
            // 
            // dataGridViewKhohang
            // 
            this.dataGridViewKhohang.AllowUserToAddRows = false;
            this.dataGridViewKhohang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewKhohang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewKhohang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8});
            this.dataGridViewKhohang.Location = new System.Drawing.Point(3, 176);
            this.dataGridViewKhohang.Name = "dataGridViewKhohang";
            this.dataGridViewKhohang.RowHeadersWidth = 51;
            this.dataGridViewKhohang.Size = new System.Drawing.Size(741, 203);
            this.dataGridViewKhohang.TabIndex = 1;
            this.dataGridViewKhohang.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewKhohang_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.FillWeight = 60F;
            this.Column1.HeaderText = "Mã hàng";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.FillWeight = 150F;
            this.Column2.HeaderText = "Tên hàng";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Hạn dùng";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.FillWeight = 150F;
            this.Column4.HeaderText = "Cty SX";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.FillWeight = 80F;
            this.Column5.HeaderText = "Năm SX";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.FillWeight = 80F;
            this.Column6.HeaderText = "Loại hàng";
            this.Column6.MinimumWidth = 6;
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.FillWeight = 80F;
            this.Column7.HeaderText = "Số lượng";
            this.Column7.MinimumWidth = 6;
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.FillWeight = 80F;
            this.Column8.HeaderText = "Đơn giá";
            this.Column8.MinimumWidth = 6;
            this.Column8.Name = "Column8";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbxLoaiHang);
            this.panel1.Controls.Add(this.dateTimePicker_HanDung_KhoH);
            this.panel1.Controls.Add(this.btnNhapLai);
            this.panel1.Controls.Add(this.txtDongia);
            this.panel1.Controls.Add(this.txtSoluong);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.btnXoa);
            this.panel1.Controls.Add(this.btnCapnhat);
            this.panel1.Controls.Add(this.btnThem);
            this.panel1.Controls.Add(this.txtNamSX);
            this.panel1.Controls.Add(this.txtCtySX);
            this.panel1.Controls.Add(this.txtTenhang);
            this.panel1.Controls.Add(this.txtMa);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(744, 167);
            this.panel1.TabIndex = 0;
            // 
            // cbxLoaiHang
            // 
            this.cbxLoaiHang.FormattingEnabled = true;
            this.cbxLoaiHang.Items.AddRange(new object[] {
            "Ăn uống",
            "Cơ khí",
            "Điện máy",
            "Gia dụng",
            "May mặc"});
            this.cbxLoaiHang.Location = new System.Drawing.Point(496, 36);
            this.cbxLoaiHang.Name = "cbxLoaiHang";
            this.cbxLoaiHang.Size = new System.Drawing.Size(214, 21);
            this.cbxLoaiHang.Sorted = true;
            this.cbxLoaiHang.TabIndex = 21;
            // 
            // dateTimePicker_HanDung_KhoH
            // 
            this.dateTimePicker_HanDung_KhoH.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_HanDung_KhoH.Location = new System.Drawing.Point(115, 62);
            this.dateTimePicker_HanDung_KhoH.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker_HanDung_KhoH.Name = "dateTimePicker_HanDung_KhoH";
            this.dateTimePicker_HanDung_KhoH.Size = new System.Drawing.Size(214, 20);
            this.dateTimePicker_HanDung_KhoH.TabIndex = 20;
            // 
            // btnNhapLai
            // 
            this.btnNhapLai.Location = new System.Drawing.Point(176, 127);
            this.btnNhapLai.Name = "btnNhapLai";
            this.btnNhapLai.Size = new System.Drawing.Size(75, 23);
            this.btnNhapLai.TabIndex = 19;
            this.btnNhapLai.Text = "Nhập lại";
            this.btnNhapLai.UseVisualStyleBackColor = true;
            this.btnNhapLai.Click += new System.EventHandler(this.btnNhapLai_Click);
            // 
            // txtDongia
            // 
            this.txtDongia.Location = new System.Drawing.Point(496, 88);
            this.txtDongia.Name = "txtDongia";
            this.txtDongia.Size = new System.Drawing.Size(214, 20);
            this.txtDongia.TabIndex = 18;
            // 
            // txtSoluong
            // 
            this.txtSoluong.Location = new System.Drawing.Point(496, 62);
            this.txtSoluong.Name = "txtSoluong";
            this.txtSoluong.Size = new System.Drawing.Size(214, 20);
            this.txtSoluong.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(446, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Đơn giá";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(441, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Số lượng";
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(628, 127);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(82, 23);
            this.btnXoa.TabIndex = 14;
            this.btnXoa.Text = "Xóa dòng";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnCapnhat
            // 
            this.btnCapnhat.Location = new System.Drawing.Point(325, 127);
            this.btnCapnhat.Name = "btnCapnhat";
            this.btnCapnhat.Size = new System.Drawing.Size(118, 23);
            this.btnCapnhat.TabIndex = 13;
            this.btnCapnhat.Text = "Sửa";
            this.btnCapnhat.UseVisualStyleBackColor = true;
            this.btnCapnhat.Click += new System.EventHandler(this.btnCapnhat_Click);
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(52, 127);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(118, 23);
            this.btnThem.TabIndex = 12;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // txtNamSX
            // 
            this.txtNamSX.Location = new System.Drawing.Point(496, 10);
            this.txtNamSX.Name = "txtNamSX";
            this.txtNamSX.Size = new System.Drawing.Size(214, 20);
            this.txtNamSX.TabIndex = 10;
            // 
            // txtCtySX
            // 
            this.txtCtySX.Location = new System.Drawing.Point(115, 86);
            this.txtCtySX.Name = "txtCtySX";
            this.txtCtySX.Size = new System.Drawing.Size(214, 20);
            this.txtCtySX.TabIndex = 9;
            // 
            // txtTenhang
            // 
            this.txtTenhang.Location = new System.Drawing.Point(115, 36);
            this.txtTenhang.Name = "txtTenhang";
            this.txtTenhang.Size = new System.Drawing.Size(214, 20);
            this.txtTenhang.TabIndex = 7;
            // 
            // txtMa
            // 
            this.txtMa.Location = new System.Drawing.Point(115, 10);
            this.txtMa.Name = "txtMa";
            this.txtMa.Size = new System.Drawing.Size(214, 20);
            this.txtMa.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(436, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Loại hàng";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(418, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Năm sản xuất";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Công ty Sản xuất";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Hạn dùng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên hàng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã hàng";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Peru;
            this.tabPage2.Controls.Add(this.dataGridViewTimKiem);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(750, 385);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tìm kiếm";
            // 
            // dataGridViewTimKiem
            // 
            this.dataGridViewTimKiem.AllowUserToAddRows = false;
            this.dataGridViewTimKiem.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewTimKiem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTimKiem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16});
            this.dataGridViewTimKiem.Location = new System.Drawing.Point(6, 222);
            this.dataGridViewTimKiem.Name = "dataGridViewTimKiem";
            this.dataGridViewTimKiem.RowHeadersWidth = 51;
            this.dataGridViewTimKiem.Size = new System.Drawing.Size(718, 157);
            this.dataGridViewTimKiem.TabIndex = 1;
            this.dataGridViewTimKiem.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTimKiem_CellContentClick);
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Mã hàng";
            this.Column9.MinimumWidth = 6;
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Tên hàng";
            this.Column10.MinimumWidth = 6;
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Hạn dùng";
            this.Column11.MinimumWidth = 6;
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Công ty SX";
            this.Column12.MinimumWidth = 6;
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Năm SX";
            this.Column13.MinimumWidth = 6;
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Loại hàng";
            this.Column14.MinimumWidth = 6;
            this.Column14.Name = "Column14";
            // 
            // Column15
            // 
            this.Column15.HeaderText = "Số lượng";
            this.Column15.MinimumWidth = 6;
            this.Column15.Name = "Column15";
            // 
            // Column16
            // 
            this.Column16.HeaderText = "Đơn giá";
            this.Column16.MinimumWidth = 6;
            this.Column16.Name = "Column16";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.dateTimePickerTimDen);
            this.panel2.Controls.Add(this.dateTimePicker_TimTu);
            this.panel2.Controls.Add(this.btnNhapTimKiem_Again);
            this.panel2.Controls.Add(this.btnXoaTimKiem);
            this.panel2.Controls.Add(this.txtTimLoaiHang);
            this.panel2.Controls.Add(this.txtTimNamSX);
            this.panel2.Controls.Add(this.txtTimCty);
            this.panel2.Controls.Add(this.txtTimTenHang);
            this.panel2.Controls.Add(this.txtTimMa);
            this.panel2.Controls.Add(this.btnTimKiem);
            this.panel2.Controls.Add(this.chkBoxLoaiHang);
            this.panel2.Controls.Add(this.chkBoxNamSX);
            this.panel2.Controls.Add(this.chkBoxCty);
            this.panel2.Controls.Add(this.chkBoxHanDung);
            this.panel2.Controls.Add(this.chkBoxTenhang);
            this.panel2.Controls.Add(this.chkBoxMa);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(721, 213);
            this.panel2.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(260, 67);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 13);
            this.label14.TabIndex = 21;
            this.label14.Text = "đến ngày";
            // 
            // dateTimePickerTimDen
            // 
            this.dateTimePickerTimDen.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerTimDen.Location = new System.Drawing.Point(316, 64);
            this.dateTimePickerTimDen.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePickerTimDen.Name = "dateTimePickerTimDen";
            this.dateTimePickerTimDen.Size = new System.Drawing.Size(151, 20);
            this.dateTimePickerTimDen.TabIndex = 19;
            // 
            // dateTimePicker_TimTu
            // 
            this.dateTimePicker_TimTu.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_TimTu.Location = new System.Drawing.Point(133, 64);
            this.dateTimePicker_TimTu.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker_TimTu.Name = "dateTimePicker_TimTu";
            this.dateTimePicker_TimTu.Size = new System.Drawing.Size(123, 20);
            this.dateTimePicker_TimTu.TabIndex = 18;
            // 
            // btnNhapTimKiem_Again
            // 
            this.btnNhapTimKiem_Again.Location = new System.Drawing.Point(202, 160);
            this.btnNhapTimKiem_Again.Name = "btnNhapTimKiem_Again";
            this.btnNhapTimKiem_Again.Size = new System.Drawing.Size(75, 23);
            this.btnNhapTimKiem_Again.TabIndex = 17;
            this.btnNhapTimKiem_Again.Text = "Nhập lại";
            this.btnNhapTimKiem_Again.UseVisualStyleBackColor = true;
            this.btnNhapTimKiem_Again.Click += new System.EventHandler(this.btnNhapTimKiem_Again_Click);
            // 
            // btnXoaTimKiem
            // 
            this.btnXoaTimKiem.Enabled = false;
            this.btnXoaTimKiem.Location = new System.Drawing.Point(202, 187);
            this.btnXoaTimKiem.Name = "btnXoaTimKiem";
            this.btnXoaTimKiem.Size = new System.Drawing.Size(141, 23);
            this.btnXoaTimKiem.TabIndex = 15;
            this.btnXoaTimKiem.Text = "Xóa kết quả tìm";
            this.btnXoaTimKiem.UseVisualStyleBackColor = true;
            this.btnXoaTimKiem.Click += new System.EventHandler(this.btnXoaTimKiem_Click);
            // 
            // txtTimLoaiHang
            // 
            this.txtTimLoaiHang.Location = new System.Drawing.Point(106, 136);
            this.txtTimLoaiHang.Name = "txtTimLoaiHang";
            this.txtTimLoaiHang.Size = new System.Drawing.Size(238, 20);
            this.txtTimLoaiHang.TabIndex = 14;
            this.txtTimLoaiHang.TextChanged += new System.EventHandler(this.txtTimLoaiHang_TextChanged);
            // 
            // txtTimNamSX
            // 
            this.txtTimNamSX.Location = new System.Drawing.Point(105, 111);
            this.txtTimNamSX.Name = "txtTimNamSX";
            this.txtTimNamSX.Size = new System.Drawing.Size(238, 20);
            this.txtTimNamSX.TabIndex = 13;
            this.txtTimNamSX.TextChanged += new System.EventHandler(this.txtTimNamSX_TextChanged);
            // 
            // txtTimCty
            // 
            this.txtTimCty.Location = new System.Drawing.Point(105, 87);
            this.txtTimCty.Name = "txtTimCty";
            this.txtTimCty.Size = new System.Drawing.Size(238, 20);
            this.txtTimCty.TabIndex = 12;
            this.txtTimCty.TextChanged += new System.EventHandler(this.txtTimCty_TextChanged);
            // 
            // txtTimTenHang
            // 
            this.txtTimTenHang.Location = new System.Drawing.Point(105, 41);
            this.txtTimTenHang.Name = "txtTimTenHang";
            this.txtTimTenHang.Size = new System.Drawing.Size(238, 20);
            this.txtTimTenHang.TabIndex = 10;
            this.txtTimTenHang.TextChanged += new System.EventHandler(this.txtTimTenHang_TextChanged);
            // 
            // txtTimMa
            // 
            this.txtTimMa.Location = new System.Drawing.Point(105, 18);
            this.txtTimMa.Name = "txtTimMa";
            this.txtTimMa.Size = new System.Drawing.Size(238, 20);
            this.txtTimMa.TabIndex = 9;
            this.txtTimMa.TextChanged += new System.EventHandler(this.txtTimMa_TextChanged);
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.Location = new System.Drawing.Point(19, 160);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(153, 50);
            this.btnTimKiem.TabIndex = 8;
            this.btnTimKiem.Text = "Tìm Kiếm";
            this.btnTimKiem.UseVisualStyleBackColor = true;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // chkBoxLoaiHang
            // 
            this.chkBoxLoaiHang.AutoSize = true;
            this.chkBoxLoaiHang.Location = new System.Drawing.Point(19, 136);
            this.chkBoxLoaiHang.Name = "chkBoxLoaiHang";
            this.chkBoxLoaiHang.Size = new System.Drawing.Size(73, 17);
            this.chkBoxLoaiHang.TabIndex = 7;
            this.chkBoxLoaiHang.Text = "Loại hàng";
            this.chkBoxLoaiHang.UseVisualStyleBackColor = true;
            // 
            // chkBoxNamSX
            // 
            this.chkBoxNamSX.AutoSize = true;
            this.chkBoxNamSX.Location = new System.Drawing.Point(19, 113);
            this.chkBoxNamSX.Name = "chkBoxNamSX";
            this.chkBoxNamSX.Size = new System.Drawing.Size(65, 17);
            this.chkBoxNamSX.TabIndex = 6;
            this.chkBoxNamSX.Text = "Năm SX";
            this.chkBoxNamSX.UseVisualStyleBackColor = true;
            // 
            // chkBoxCty
            // 
            this.chkBoxCty.AutoSize = true;
            this.chkBoxCty.Location = new System.Drawing.Point(19, 90);
            this.chkBoxCty.Name = "chkBoxCty";
            this.chkBoxCty.Size = new System.Drawing.Size(62, 17);
            this.chkBoxCty.TabIndex = 5;
            this.chkBoxCty.Text = "Công ty";
            this.chkBoxCty.UseVisualStyleBackColor = true;
            // 
            // chkBoxHanDung
            // 
            this.chkBoxHanDung.AutoSize = true;
            this.chkBoxHanDung.Location = new System.Drawing.Point(19, 67);
            this.chkBoxHanDung.Name = "chkBoxHanDung";
            this.chkBoxHanDung.Size = new System.Drawing.Size(111, 17);
            this.chkBoxHanDung.TabIndex = 4;
            this.chkBoxHanDung.Text = "Hạn dùng từ ngày";
            this.chkBoxHanDung.UseVisualStyleBackColor = true;
            // 
            // chkBoxTenhang
            // 
            this.chkBoxTenhang.AutoSize = true;
            this.chkBoxTenhang.Location = new System.Drawing.Point(19, 44);
            this.chkBoxTenhang.Name = "chkBoxTenhang";
            this.chkBoxTenhang.Size = new System.Drawing.Size(72, 17);
            this.chkBoxTenhang.TabIndex = 3;
            this.chkBoxTenhang.Text = "Tên hàng";
            this.chkBoxTenhang.UseVisualStyleBackColor = true;
            // 
            // chkBoxMa
            // 
            this.chkBoxMa.AutoSize = true;
            this.chkBoxMa.Location = new System.Drawing.Point(19, 21);
            this.chkBoxMa.Name = "chkBoxMa";
            this.chkBoxMa.Size = new System.Drawing.Size(68, 17);
            this.chkBoxMa.TabIndex = 2;
            this.chkBoxMa.Text = "Mã hàng";
            this.chkBoxMa.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Peru;
            this.tabPage3.Controls.Add(this.dataGridViewXuatBan);
            this.tabPage3.Controls.Add(this.panel3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(750, 385);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Xuất bán";
            // 
            // dataGridViewXuatBan
            // 
            this.dataGridViewXuatBan.AllowUserToAddRows = false;
            this.dataGridViewXuatBan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewXuatBan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewXuatBan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21,
            this.Column22,
            this.Column23});
            this.dataGridViewXuatBan.Location = new System.Drawing.Point(3, 171);
            this.dataGridViewXuatBan.Name = "dataGridViewXuatBan";
            this.dataGridViewXuatBan.RowHeadersWidth = 51;
            this.dataGridViewXuatBan.Size = new System.Drawing.Size(724, 167);
            this.dataGridViewXuatBan.TabIndex = 1;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Mã hàng";
            this.Column17.MinimumWidth = 6;
            this.Column17.Name = "Column17";
            // 
            // Column18
            // 
            this.Column18.HeaderText = "Tên hàng";
            this.Column18.MinimumWidth = 6;
            this.Column18.Name = "Column18";
            // 
            // Column19
            // 
            this.Column19.HeaderText = "Số lượng";
            this.Column19.MinimumWidth = 6;
            this.Column19.Name = "Column19";
            // 
            // Column20
            // 
            this.Column20.HeaderText = "Giá nhập";
            this.Column20.MinimumWidth = 6;
            this.Column20.Name = "Column20";
            // 
            // Column21
            // 
            this.Column21.HeaderText = "Giá xuất";
            this.Column21.MinimumWidth = 6;
            this.Column21.Name = "Column21";
            // 
            // Column22
            // 
            this.Column22.HeaderText = "Tiền lãi";
            this.Column22.MinimumWidth = 6;
            this.Column22.Name = "Column22";
            // 
            // Column23
            // 
            this.Column23.HeaderText = "Ngày bán";
            this.Column23.Name = "Column23";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dateTimePicker_NgayBan_XB);
            this.panel3.Controls.Add(this.btnXuatBan);
            this.panel3.Controls.Add(this.txtGiaBan);
            this.panel3.Controls.Add(this.txtSoluongBan);
            this.panel3.Controls.Add(this.txtMahangBan);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(724, 162);
            this.panel3.TabIndex = 0;
            // 
            // dateTimePicker_NgayBan_XB
            // 
            this.dateTimePicker_NgayBan_XB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_NgayBan_XB.Location = new System.Drawing.Point(83, 107);
            this.dateTimePicker_NgayBan_XB.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker_NgayBan_XB.Name = "dateTimePicker_NgayBan_XB";
            this.dateTimePicker_NgayBan_XB.Size = new System.Drawing.Size(205, 20);
            this.dateTimePicker_NgayBan_XB.TabIndex = 9;
            // 
            // btnXuatBan
            // 
            this.btnXuatBan.Location = new System.Drawing.Point(83, 134);
            this.btnXuatBan.Name = "btnXuatBan";
            this.btnXuatBan.Size = new System.Drawing.Size(205, 23);
            this.btnXuatBan.TabIndex = 8;
            this.btnXuatBan.Text = "Xuất hàng";
            this.btnXuatBan.UseVisualStyleBackColor = true;
            this.btnXuatBan.Click += new System.EventHandler(this.btnXuatBan_Click);
            // 
            // txtGiaBan
            // 
            this.txtGiaBan.Location = new System.Drawing.Point(83, 78);
            this.txtGiaBan.Name = "txtGiaBan";
            this.txtGiaBan.Size = new System.Drawing.Size(205, 20);
            this.txtGiaBan.TabIndex = 6;
            // 
            // txtSoluongBan
            // 
            this.txtSoluongBan.Location = new System.Drawing.Point(83, 51);
            this.txtSoluongBan.Name = "txtSoluongBan";
            this.txtSoluongBan.Size = new System.Drawing.Size(205, 20);
            this.txtSoluongBan.TabIndex = 5;
            // 
            // txtMahangBan
            // 
            this.txtMahangBan.Location = new System.Drawing.Point(83, 23);
            this.txtMahangBan.Name = "txtMahangBan";
            this.txtMahangBan.Size = new System.Drawing.Size(205, 20);
            this.txtMahangBan.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(24, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Ngày bán";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(33, 81);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Giá bán";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(28, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Số lượng";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Mã hàng";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Peru;
            this.tabPage4.Controls.Add(this.dataGridViewHangBan_LK);
            this.tabPage4.Controls.Add(this.panel4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(750, 385);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Liệt kê hàng bán";
            // 
            // dataGridViewHangBan_LK
            // 
            this.dataGridViewHangBan_LK.AllowUserToAddRows = false;
            this.dataGridViewHangBan_LK.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewHangBan_LK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHangBan_LK.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.dataGridViewHangBan_LK.Location = new System.Drawing.Point(3, 149);
            this.dataGridViewHangBan_LK.Name = "dataGridViewHangBan_LK";
            this.dataGridViewHangBan_LK.RowHeadersWidth = 51;
            this.dataGridViewHangBan_LK.Size = new System.Drawing.Size(724, 167);
            this.dataGridViewHangBan_LK.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Mã hàng";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Tên hàng";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Số lượng";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Giá nhập";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Giá xuất";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Tiền lãi";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Ngày bán";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btn_Xoa_BangLK);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.dateTimePickerBanDenNgay_LK);
            this.panel4.Controls.Add(this.dateTimePicker_BanTuNgay_LK);
            this.panel4.Controls.Add(this.chkBox_NgayBan_LK);
            this.panel4.Controls.Add(this.txtMaHangLKBan);
            this.panel4.Controls.Add(this.chkBoxMaHangBan_LK);
            this.panel4.Controls.Add(this.btnLietKeHangBan);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(721, 149);
            this.panel4.TabIndex = 1;
            // 
            // btn_Xoa_BangLK
            // 
            this.btn_Xoa_BangLK.Location = new System.Drawing.Point(222, 105);
            this.btn_Xoa_BangLK.Name = "btn_Xoa_BangLK";
            this.btn_Xoa_BangLK.Size = new System.Drawing.Size(126, 23);
            this.btn_Xoa_BangLK.TabIndex = 32;
            this.btn_Xoa_BangLK.Text = "Xóa bảng liệt kê";
            this.btn_Xoa_BangLK.UseVisualStyleBackColor = true;
            this.btn_Xoa_BangLK.Click += new System.EventHandler(this.btn_Xoa_BangLK_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(235, 38);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 31;
            this.label13.Text = "đến ngày";
            // 
            // dateTimePickerBanDenNgay_LK
            // 
            this.dateTimePickerBanDenNgay_LK.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerBanDenNgay_LK.Location = new System.Drawing.Point(291, 35);
            this.dateTimePickerBanDenNgay_LK.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePickerBanDenNgay_LK.Name = "dateTimePickerBanDenNgay_LK";
            this.dateTimePickerBanDenNgay_LK.Size = new System.Drawing.Size(151, 20);
            this.dateTimePickerBanDenNgay_LK.TabIndex = 30;
            // 
            // dateTimePicker_BanTuNgay_LK
            // 
            this.dateTimePicker_BanTuNgay_LK.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_BanTuNgay_LK.Location = new System.Drawing.Point(109, 35);
            this.dateTimePicker_BanTuNgay_LK.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker_BanTuNgay_LK.Name = "dateTimePicker_BanTuNgay_LK";
            this.dateTimePicker_BanTuNgay_LK.Size = new System.Drawing.Size(123, 20);
            this.dateTimePicker_BanTuNgay_LK.TabIndex = 29;
            // 
            // chkBox_NgayBan_LK
            // 
            this.chkBox_NgayBan_LK.AutoSize = true;
            this.chkBox_NgayBan_LK.Location = new System.Drawing.Point(21, 38);
            this.chkBox_NgayBan_LK.Name = "chkBox_NgayBan_LK";
            this.chkBox_NgayBan_LK.Size = new System.Drawing.Size(83, 17);
            this.chkBox_NgayBan_LK.TabIndex = 28;
            this.chkBox_NgayBan_LK.Text = "Bán từ ngày";
            this.chkBox_NgayBan_LK.UseVisualStyleBackColor = true;
            // 
            // txtMaHangLKBan
            // 
            this.txtMaHangLKBan.Location = new System.Drawing.Point(95, 12);
            this.txtMaHangLKBan.Name = "txtMaHangLKBan";
            this.txtMaHangLKBan.Size = new System.Drawing.Size(238, 20);
            this.txtMaHangLKBan.TabIndex = 26;
            // 
            // chkBoxMaHangBan_LK
            // 
            this.chkBoxMaHangBan_LK.AutoSize = true;
            this.chkBoxMaHangBan_LK.Location = new System.Drawing.Point(21, 15);
            this.chkBoxMaHangBan_LK.Name = "chkBoxMaHangBan_LK";
            this.chkBoxMaHangBan_LK.Size = new System.Drawing.Size(68, 17);
            this.chkBoxMaHangBan_LK.TabIndex = 15;
            this.chkBoxMaHangBan_LK.Text = "Mã hàng";
            this.chkBoxMaHangBan_LK.UseVisualStyleBackColor = true;
            // 
            // btnLietKeHangBan
            // 
            this.btnLietKeHangBan.Location = new System.Drawing.Point(21, 78);
            this.btnLietKeHangBan.Name = "btnLietKeHangBan";
            this.btnLietKeHangBan.Size = new System.Drawing.Size(153, 50);
            this.btnLietKeHangBan.TabIndex = 8;
            this.btnLietKeHangBan.Text = "Liệt kê hàng bán";
            this.btnLietKeHangBan.UseVisualStyleBackColor = true;
            this.btnLietKeHangBan.Click += new System.EventHandler(this.btnLietKeHangBan_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(750, 385);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Tác Giả";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(188, 73);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(106, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Họ tên: Trần Quế Tử";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(188, 102);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "MSSV: 20880089";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Phần Mềm Quản Lý Cửa Hàng";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKhohang)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTimKiem)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewXuatBan)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHangBan_LK)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridViewKhohang;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnCapnhat;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.TextBox txtNamSX;
        private System.Windows.Forms.TextBox txtCtySX;
        private System.Windows.Forms.TextBox txtTenhang;
        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.TextBox txtDongia;
        private System.Windows.Forms.TextBox txtSoluong;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridViewTimKiem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtTimLoaiHang;
        private System.Windows.Forms.TextBox txtTimNamSX;
        private System.Windows.Forms.TextBox txtTimCty;
        private System.Windows.Forms.TextBox txtTimTenHang;
        private System.Windows.Forms.TextBox txtTimMa;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.CheckBox chkBoxLoaiHang;
        private System.Windows.Forms.CheckBox chkBoxNamSX;
        private System.Windows.Forms.CheckBox chkBoxCty;
        private System.Windows.Forms.CheckBox chkBoxHanDung;
        private System.Windows.Forms.CheckBox chkBoxTenhang;
        private System.Windows.Forms.CheckBox chkBoxMa;
        private System.Windows.Forms.DataGridView dataGridViewXuatBan;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.Button btnXuatBan;
        private System.Windows.Forms.TextBox txtGiaBan;
        private System.Windows.Forms.TextBox txtSoluongBan;
        private System.Windows.Forms.TextBox txtMahangBan;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtMaHangLKBan;
        private System.Windows.Forms.CheckBox chkBoxMaHangBan_LK;
        private System.Windows.Forms.Button btnLietKeHangBan;
        private System.Windows.Forms.Button btnNhapLai;
        private System.Windows.Forms.Button btnXoaTimKiem;
        private System.Windows.Forms.Button btnNhapTimKiem_Again;
        private System.Windows.Forms.DateTimePicker dateTimePicker_HanDung_KhoH;
        private System.Windows.Forms.DateTimePicker dateTimePicker_NgayBan_XB;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dateTimePickerTimDen;
        private System.Windows.Forms.DateTimePicker dateTimePicker_TimTu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.ComboBox cbxLoaiHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dateTimePickerBanDenNgay_LK;
        private System.Windows.Forms.DateTimePicker dateTimePicker_BanTuNgay_LK;
        private System.Windows.Forms.CheckBox chkBox_NgayBan_LK;
        private System.Windows.Forms.DataGridView dataGridViewHangBan_LK;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Button btn_Xoa_BangLK;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
    }
}

