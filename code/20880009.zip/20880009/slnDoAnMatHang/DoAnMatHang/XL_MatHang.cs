﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAnMatHang
{
    //struct MatHang
    //{
    //    public string MaHang;
    //    public string TenHang;
    //    public DateTime HanDung;
    //    public string CTYSX;
    //    public int NamSX;
    //    public string LoaiHang;
    //}
    class XL_MatHang
    {
        public static MatHang ThemMatHang(MatHang[] mhs, MatHang mh)
        {
            
            return mh;
        }
    }
}
