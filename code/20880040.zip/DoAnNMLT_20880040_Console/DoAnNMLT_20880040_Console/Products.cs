﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DoAnNMLT_20880040_Console
{
    class Products
    {
        //public Product getProductById(List<Product> products, string code)
        //{
        //    Product prod;
        //    for (int i=0; i<products.Count; i++)
        //    {
        //        if (products[i].code == code)
        //        {

        //        }
        //    }
        //    return prod;
        //}

        //public List<Product> getProductsByName(List<Product> products, string seq)
        //{
        //    List<Product> prods = null;
        //    products.ForEach(p => {
        //        if (p.name.Contains(seq))
        //        {
        //            prods.Add(p);
        //        }
        //    });

        //    return prods;
        //}

        public void updateProduct(List<Product> products, int id, string cd, string n, DateTime ed, string cm, int y)
        {

        }

        public void RemoveProduct(int id)
        {

        }
    }
}
