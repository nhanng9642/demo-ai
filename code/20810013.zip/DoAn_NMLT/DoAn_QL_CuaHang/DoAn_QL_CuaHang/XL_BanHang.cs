﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoAn_QL_CuaHang
{
    struct HANGHOA
    {
        public string Mahang;
        public string Tenhang;
        public string Hansudung;
        public string Ctysx;
        public String Namsx;
        public string Loaihang;

        public string Maloaihang;
        public string Tenloaihang;
    }
    class XL_BanHang
    {
    }
}
