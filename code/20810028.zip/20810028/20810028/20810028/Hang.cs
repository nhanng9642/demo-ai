﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20810028
{
    struct MatHang
    {
        public string maHang;
        public  string tenHang;
        public string loaiHang;
        public string hanDung;
        public string namSx;
        public string ctySx;
    }
    public class Hang
    {
       

       

}
}
