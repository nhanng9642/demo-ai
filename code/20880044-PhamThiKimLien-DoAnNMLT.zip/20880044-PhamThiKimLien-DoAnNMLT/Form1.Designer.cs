﻿namespace _20880044_PhamThiKimLien_DoAnNMLT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnThemMatHang = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMaHang = new System.Windows.Forms.TextBox();
            this.txtTenHang = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCongTySanXuat = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnXoaMatHang = new System.Windows.Forms.Button();
            this.btnTimKiemMatHang = new System.Windows.Forms.Button();
            this.btnSuaMatHang = new System.Windows.Forms.Button();
            this.listViewMatHang = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtTimKiemLoaiHang = new System.Windows.Forms.TextBox();
            this.txtLoaiHang = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnThemLoaiHang = new System.Windows.Forms.Button();
            this.listViewLoaiHang = new System.Windows.Forms.ListView();
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSuaLoaiHang = new System.Windows.Forms.Button();
            this.btnXoaLoaiHang = new System.Windows.Forms.Button();
            this.btnTimKiemLoaiHang = new System.Windows.Forms.Button();
            this.listViewTimKiemLoaiHang = new System.Windows.Forms.ListView();
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cbLoaiHang = new System.Windows.Forms.ComboBox();
            this.btnLuuLoaiHang = new System.Windows.Forms.Button();
            this.btnLuuMatHang = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.listViewTimKiemMatHang = new System.Windows.Forms.ListView();
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cbNamSanXuat = new System.Windows.Forms.ComboBox();
            this.txtTimKiemMatHang = new System.Windows.Forms.TextBox();
            this.dtpHanDung = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnThemMatHang
            // 
            this.btnThemMatHang.Location = new System.Drawing.Point(250, 114);
            this.btnThemMatHang.Name = "btnThemMatHang";
            this.btnThemMatHang.Size = new System.Drawing.Size(65, 30);
            this.btnThemMatHang.TabIndex = 0;
            this.btnThemMatHang.Text = "Thêm";
            this.btnThemMatHang.UseVisualStyleBackColor = true;
            this.btnThemMatHang.Click += new System.EventHandler(this.btnThemMatHang_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mã hàng";
            // 
            // txtMaHang
            // 
            this.txtMaHang.Location = new System.Drawing.Point(108, 101);
            this.txtMaHang.Name = "txtMaHang";
            this.txtMaHang.Size = new System.Drawing.Size(120, 20);
            this.txtMaHang.TabIndex = 2;
            // 
            // txtTenHang
            // 
            this.txtTenHang.Location = new System.Drawing.Point(108, 130);
            this.txtTenHang.Name = "txtTenHang";
            this.txtTenHang.Size = new System.Drawing.Size(120, 20);
            this.txtTenHang.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tên hàng";
            // 
            // txtCongTySanXuat
            // 
            this.txtCongTySanXuat.Location = new System.Drawing.Point(108, 187);
            this.txtCongTySanXuat.Name = "txtCongTySanXuat";
            this.txtCongTySanXuat.Size = new System.Drawing.Size(120, 20);
            this.txtCongTySanXuat.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Công ty sản xuất";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Hạn dùng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Loại hàng";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 217);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Năm sản xuất";
            // 
            // btnXoaMatHang
            // 
            this.btnXoaMatHang.Location = new System.Drawing.Point(251, 150);
            this.btnXoaMatHang.Name = "btnXoaMatHang";
            this.btnXoaMatHang.Size = new System.Drawing.Size(65, 30);
            this.btnXoaMatHang.TabIndex = 13;
            this.btnXoaMatHang.Text = "Xóa";
            this.btnXoaMatHang.UseVisualStyleBackColor = true;
            this.btnXoaMatHang.Click += new System.EventHandler(this.btnXoaMatHang_Click);
            // 
            // btnTimKiemMatHang
            // 
            this.btnTimKiemMatHang.Location = new System.Drawing.Point(250, 32);
            this.btnTimKiemMatHang.Name = "btnTimKiemMatHang";
            this.btnTimKiemMatHang.Size = new System.Drawing.Size(65, 30);
            this.btnTimKiemMatHang.TabIndex = 15;
            this.btnTimKiemMatHang.Text = "Tìm kiếm";
            this.btnTimKiemMatHang.UseVisualStyleBackColor = true;
            this.btnTimKiemMatHang.Click += new System.EventHandler(this.btnTimKiemMatHang_Click);
            // 
            // btnSuaMatHang
            // 
            this.btnSuaMatHang.Location = new System.Drawing.Point(251, 186);
            this.btnSuaMatHang.Name = "btnSuaMatHang";
            this.btnSuaMatHang.Size = new System.Drawing.Size(65, 30);
            this.btnSuaMatHang.TabIndex = 14;
            this.btnSuaMatHang.Text = "Sửa";
            this.btnSuaMatHang.UseVisualStyleBackColor = true;
            this.btnSuaMatHang.Click += new System.EventHandler(this.btnSuaMatHang_Click);
            // 
            // listViewMatHang
            // 
            this.listViewMatHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listViewMatHang.FullRowSelect = true;
            this.listViewMatHang.HideSelection = false;
            this.listViewMatHang.Location = new System.Drawing.Point(338, 101);
            this.listViewMatHang.MultiSelect = false;
            this.listViewMatHang.Name = "listViewMatHang";
            this.listViewMatHang.Size = new System.Drawing.Size(515, 164);
            this.listViewMatHang.TabIndex = 16;
            this.listViewMatHang.UseCompatibleStateImageBehavior = false;
            this.listViewMatHang.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã hàng";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tên hàng";
            this.columnHeader2.Width = 103;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Hạn dùng";
            this.columnHeader3.Width = 89;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Công ty sản xuất";
            this.columnHeader4.Width = 109;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Năm sản xuất";
            this.columnHeader5.Width = 84;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Loại hàng";
            this.columnHeader6.Width = 64;
            // 
            // txtTimKiemLoaiHang
            // 
            this.txtTimKiemLoaiHang.Location = new System.Drawing.Point(109, 36);
            this.txtTimKiemLoaiHang.Name = "txtTimKiemLoaiHang";
            this.txtTimKiemLoaiHang.Size = new System.Drawing.Size(120, 20);
            this.txtTimKiemLoaiHang.TabIndex = 17;
            // 
            // txtLoaiHang
            // 
            this.txtLoaiHang.Location = new System.Drawing.Point(109, 100);
            this.txtLoaiHang.Name = "txtLoaiHang";
            this.txtLoaiHang.Size = new System.Drawing.Size(120, 20);
            this.txtLoaiHang.TabIndex = 41;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(10, 103);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 40;
            this.label13.Text = "Loại hàng";
            // 
            // btnThemLoaiHang
            // 
            this.btnThemLoaiHang.Location = new System.Drawing.Point(252, 100);
            this.btnThemLoaiHang.Name = "btnThemLoaiHang";
            this.btnThemLoaiHang.Size = new System.Drawing.Size(65, 30);
            this.btnThemLoaiHang.TabIndex = 42;
            this.btnThemLoaiHang.Text = "Thêm";
            this.btnThemLoaiHang.UseVisualStyleBackColor = true;
            this.btnThemLoaiHang.Click += new System.EventHandler(this.btnThemLoaiHang_Click);
            // 
            // listViewLoaiHang
            // 
            this.listViewLoaiHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader18});
            this.listViewLoaiHang.FullRowSelect = true;
            this.listViewLoaiHang.HideSelection = false;
            this.listViewLoaiHang.Location = new System.Drawing.Point(339, 99);
            this.listViewLoaiHang.MultiSelect = false;
            this.listViewLoaiHang.Name = "listViewLoaiHang";
            this.listViewLoaiHang.Size = new System.Drawing.Size(147, 139);
            this.listViewLoaiHang.TabIndex = 43;
            this.listViewLoaiHang.UseCompatibleStateImageBehavior = false;
            this.listViewLoaiHang.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Loại hàng";
            this.columnHeader18.Width = 106;
            // 
            // btnSuaLoaiHang
            // 
            this.btnSuaLoaiHang.Location = new System.Drawing.Point(251, 172);
            this.btnSuaLoaiHang.Name = "btnSuaLoaiHang";
            this.btnSuaLoaiHang.Size = new System.Drawing.Size(65, 30);
            this.btnSuaLoaiHang.TabIndex = 44;
            this.btnSuaLoaiHang.Text = "Sửa";
            this.btnSuaLoaiHang.UseVisualStyleBackColor = true;
            this.btnSuaLoaiHang.Click += new System.EventHandler(this.btnSuaLoaiHang_Click);
            // 
            // btnXoaLoaiHang
            // 
            this.btnXoaLoaiHang.Location = new System.Drawing.Point(251, 136);
            this.btnXoaLoaiHang.Name = "btnXoaLoaiHang";
            this.btnXoaLoaiHang.Size = new System.Drawing.Size(65, 30);
            this.btnXoaLoaiHang.TabIndex = 45;
            this.btnXoaLoaiHang.Text = "Xóa";
            this.btnXoaLoaiHang.UseVisualStyleBackColor = true;
            this.btnXoaLoaiHang.Click += new System.EventHandler(this.btnXoaLoaiHang_Click);
            // 
            // btnTimKiemLoaiHang
            // 
            this.btnTimKiemLoaiHang.Location = new System.Drawing.Point(251, 30);
            this.btnTimKiemLoaiHang.Name = "btnTimKiemLoaiHang";
            this.btnTimKiemLoaiHang.Size = new System.Drawing.Size(65, 30);
            this.btnTimKiemLoaiHang.TabIndex = 46;
            this.btnTimKiemLoaiHang.Text = "Tìm kiếm";
            this.btnTimKiemLoaiHang.UseVisualStyleBackColor = true;
            this.btnTimKiemLoaiHang.Click += new System.EventHandler(this.btnTimKiemLoaiHang_Click);
            // 
            // listViewTimKiemLoaiHang
            // 
            this.listViewTimKiemLoaiHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader13});
            this.listViewTimKiemLoaiHang.FullRowSelect = true;
            this.listViewTimKiemLoaiHang.HideSelection = false;
            this.listViewTimKiemLoaiHang.Location = new System.Drawing.Point(339, 99);
            this.listViewTimKiemLoaiHang.MultiSelect = false;
            this.listViewTimKiemLoaiHang.Name = "listViewTimKiemLoaiHang";
            this.listViewTimKiemLoaiHang.Size = new System.Drawing.Size(147, 138);
            this.listViewTimKiemLoaiHang.TabIndex = 47;
            this.listViewTimKiemLoaiHang.UseCompatibleStateImageBehavior = false;
            this.listViewTimKiemLoaiHang.View = System.Windows.Forms.View.Details;
            this.listViewTimKiemLoaiHang.Visible = false;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Loại hàng";
            this.columnHeader13.Width = 106;
            // 
            // cbLoaiHang
            // 
            this.cbLoaiHang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLoaiHang.FormattingEnabled = true;
            this.cbLoaiHang.Location = new System.Drawing.Point(108, 245);
            this.cbLoaiHang.Name = "cbLoaiHang";
            this.cbLoaiHang.Size = new System.Drawing.Size(120, 21);
            this.cbLoaiHang.TabIndex = 48;
            // 
            // btnLuuLoaiHang
            // 
            this.btnLuuLoaiHang.Enabled = false;
            this.btnLuuLoaiHang.Location = new System.Drawing.Point(251, 208);
            this.btnLuuLoaiHang.Name = "btnLuuLoaiHang";
            this.btnLuuLoaiHang.Size = new System.Drawing.Size(65, 30);
            this.btnLuuLoaiHang.TabIndex = 49;
            this.btnLuuLoaiHang.Text = "Lưu";
            this.btnLuuLoaiHang.UseVisualStyleBackColor = true;
            this.btnLuuLoaiHang.Click += new System.EventHandler(this.btnLuuLoaiHang_Click);
            // 
            // btnLuuMatHang
            // 
            this.btnLuuMatHang.Enabled = false;
            this.btnLuuMatHang.Location = new System.Drawing.Point(251, 222);
            this.btnLuuMatHang.Name = "btnLuuMatHang";
            this.btnLuuMatHang.Size = new System.Drawing.Size(65, 30);
            this.btnLuuMatHang.TabIndex = 50;
            this.btnLuuMatHang.Text = "Lưu";
            this.btnLuuMatHang.UseVisualStyleBackColor = true;
            this.btnLuuMatHang.Click += new System.EventHandler(this.btnLuuMatHang_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.listViewLoaiHang);
            this.groupBox1.Controls.Add(this.btnThemLoaiHang);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.listViewTimKiemLoaiHang);
            this.groupBox1.Controls.Add(this.btnTimKiemLoaiHang);
            this.groupBox1.Controls.Add(this.btnXoaLoaiHang);
            this.groupBox1.Controls.Add(this.txtLoaiHang);
            this.groupBox1.Controls.Add(this.btnLuuLoaiHang);
            this.groupBox1.Controls.Add(this.btnSuaLoaiHang);
            this.groupBox1.Controls.Add(this.txtTimKiemLoaiHang);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(17, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox1.Size = new System.Drawing.Size(889, 253);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "LOẠI HÀNG";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(336, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(422, 13);
            this.label7.TabIndex = 50;
            this.label7.Text = "Bảng sẽ hiện lại toàn bộ danh sách Loại hàng nếu để trống textbox và bấm nút tìm " +
    "kiếm";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.listViewTimKiemMatHang);
            this.groupBox2.Controls.Add(this.cbNamSanXuat);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtTimKiemMatHang);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.dtpHanDung);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cbLoaiHang);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtMaHang);
            this.groupBox2.Controls.Add(this.btnXoaMatHang);
            this.groupBox2.Controls.Add(this.listViewMatHang);
            this.groupBox2.Controls.Add(this.btnTimKiemMatHang);
            this.groupBox2.Controls.Add(this.txtTenHang);
            this.groupBox2.Controls.Add(this.btnSuaMatHang);
            this.groupBox2.Controls.Add(this.btnThemMatHang);
            this.groupBox2.Controls.Add(this.txtCongTySanXuat);
            this.groupBox2.Controls.Add(this.btnLuuMatHang);
            this.groupBox2.Location = new System.Drawing.Point(18, 300);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(889, 280);
            this.groupBox2.TabIndex = 53;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "MẶT HÀNG";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(335, 41);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(420, 13);
            this.label8.TabIndex = 51;
            this.label8.Text = "Bảng sẽ hiện lại toàn bộ danh sách Mặt hàng nếu để trống textbox và bấm nút tìm k" +
    "iếm";
            // 
            // listViewTimKiemMatHang
            // 
            this.listViewTimKiemMatHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader17,
            this.columnHeader19,
            this.columnHeader20});
            this.listViewTimKiemMatHang.FullRowSelect = true;
            this.listViewTimKiemMatHang.HideSelection = false;
            this.listViewTimKiemMatHang.Location = new System.Drawing.Point(338, 101);
            this.listViewTimKiemMatHang.MultiSelect = false;
            this.listViewTimKiemMatHang.Name = "listViewTimKiemMatHang";
            this.listViewTimKiemMatHang.Size = new System.Drawing.Size(515, 164);
            this.listViewTimKiemMatHang.TabIndex = 51;
            this.listViewTimKiemMatHang.UseCompatibleStateImageBehavior = false;
            this.listViewTimKiemMatHang.View = System.Windows.Forms.View.Details;
            this.listViewTimKiemMatHang.Visible = false;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Mã hàng";
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Tên hàng";
            this.columnHeader15.Width = 103;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Hạn dùng";
            this.columnHeader16.Width = 89;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Công ty sản xuất";
            this.columnHeader17.Width = 109;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Năm sản xuất";
            this.columnHeader19.Width = 84;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Loại hàng";
            this.columnHeader20.Width = 64;
            // 
            // cbNamSanXuat
            // 
            this.cbNamSanXuat.DisplayMember = "\"\"";
            this.cbNamSanXuat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNamSanXuat.FormattingEnabled = true;
            this.cbNamSanXuat.Location = new System.Drawing.Point(108, 214);
            this.cbNamSanXuat.Name = "cbNamSanXuat";
            this.cbNamSanXuat.Size = new System.Drawing.Size(120, 21);
            this.cbNamSanXuat.TabIndex = 55;
            // 
            // txtTimKiemMatHang
            // 
            this.txtTimKiemMatHang.Location = new System.Drawing.Point(108, 38);
            this.txtTimKiemMatHang.Name = "txtTimKiemMatHang";
            this.txtTimKiemMatHang.Size = new System.Drawing.Size(120, 20);
            this.txtTimKiemMatHang.TabIndex = 68;
            // 
            // dtpHanDung
            // 
            this.dtpHanDung.CustomFormat = "";
            this.dtpHanDung.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpHanDung.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.dtpHanDung.Location = new System.Drawing.Point(108, 156);
            this.dtpHanDung.MaxDate = new System.DateTime(2021, 12, 31, 0, 0, 0, 0);
            this.dtpHanDung.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dtpHanDung.Name = "dtpHanDung";
            this.dtpHanDung.Size = new System.Drawing.Size(120, 20);
            this.dtpHanDung.TabIndex = 56;
            this.dtpHanDung.Value = new System.DateTime(2020, 12, 11, 21, 40, 36, 0);
            this.dtpHanDung.ValueChanged += new System.EventHandler(this.dtpHanDung_ValueChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 603);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnThemMatHang;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMaHang;
        private System.Windows.Forms.TextBox txtTenHang;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCongTySanXuat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnXoaMatHang;
        private System.Windows.Forms.Button btnTimKiemMatHang;
        private System.Windows.Forms.Button btnSuaMatHang;
        private System.Windows.Forms.ListView listViewMatHang;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.TextBox txtTimKiemLoaiHang;
        private System.Windows.Forms.TextBox txtLoaiHang;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnThemLoaiHang;
        private System.Windows.Forms.ListView listViewLoaiHang;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.Button btnSuaLoaiHang;
        private System.Windows.Forms.Button btnXoaLoaiHang;
        private System.Windows.Forms.Button btnTimKiemLoaiHang;
        private System.Windows.Forms.ListView listViewTimKiemLoaiHang;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ComboBox cbLoaiHang;
        private System.Windows.Forms.Button btnLuuLoaiHang;
        private System.Windows.Forms.Button btnLuuMatHang;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListView listViewTimKiemMatHang;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.TextBox txtTimKiemMatHang;
        private System.Windows.Forms.ComboBox cbNamSanXuat;
        private System.Windows.Forms.DateTimePicker dtpHanDung;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

