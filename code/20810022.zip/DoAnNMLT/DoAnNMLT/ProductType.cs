﻿namespace DoAnNMLT
{
    class ProductType
    {
        public string typeName;
        public string typeCode;
        
        public ProductType(string name, string code)
        {
            typeName = name;
            typeCode = code;            
        }
    }
}
