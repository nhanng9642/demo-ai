﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Đồ_án
{
    struct HANG
    {
        public string TenMH;
        public string MaMH;
        public string Cty;
        public string NamSX;
        public string HSD;
        public string LoaiHang;
    }
}
