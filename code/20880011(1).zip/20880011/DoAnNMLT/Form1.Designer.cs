﻿namespace DoAnNMLT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelLoaiHang = new System.Windows.Forms.Panel();
            this.txtLHTimKiemLH = new System.Windows.Forms.TextBox();
            this.btnLHHuy = new System.Windows.Forms.Button();
            this.btnLHLuu = new System.Windows.Forms.Button();
            this.btnLHTimKiem = new System.Windows.Forms.Button();
            this.btnLHXoaLH = new System.Windows.Forms.Button();
            this.btnLHSuaLH = new System.Windows.Forms.Button();
            this.btnLHThemLH = new System.Windows.Forms.Button();
            this.lbLHLoaiHang = new System.Windows.Forms.Label();
            this.txtLHLoaiHang = new System.Windows.Forms.TextBox();
            this.panelMatHang = new System.Windows.Forms.Panel();
            this.btnMHHuy = new System.Windows.Forms.Button();
            this.btnMHLuu = new System.Windows.Forms.Button();
            this.btnMHXoaMH = new System.Windows.Forms.Button();
            this.btnMHSuaMH = new System.Windows.Forms.Button();
            this.btnMHThemMH = new System.Windows.Forms.Button();
            this.comboBoxLoaiHang = new System.Windows.Forms.ComboBox();
            this.DateTimePickerHanSD = new System.Windows.Forms.DateTimePicker();
            this.lbMHHanSD = new System.Windows.Forms.Label();
            this.lbMHLoaiHang = new System.Windows.Forms.Label();
            this.txtMHNamSX = new System.Windows.Forms.TextBox();
            this.lbMHNamSX = new System.Windows.Forms.Label();
            this.txtMHTenCty = new System.Windows.Forms.TextBox();
            this.lbMHTenCty = new System.Windows.Forms.Label();
            this.txtMHTenMH = new System.Windows.Forms.TextBox();
            this.lbMHTenMH = new System.Windows.Forms.Label();
            this.txtMHMaMH = new System.Windows.Forms.TextBox();
            this.lbMHMaMH = new System.Windows.Forms.Label();
            this.btnMHTimKiemMaMH = new System.Windows.Forms.Button();
            this.dataGridViewMatHang = new System.Windows.Forms.DataGridView();
            this.ColumnMHMaMH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMHTenMH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMHTenCty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMHLoaiHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMHHanSD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMHNamSX = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewLoaiHang = new System.Windows.Forms.DataGridView();
            this.ColumnLHLoaiHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelTimKiemMH = new System.Windows.Forms.Panel();
            this.btnMHHuyTimKiem = new System.Windows.Forms.Button();
            this.txtTKMaMH = new System.Windows.Forms.TextBox();
            this.btnLHHuyTimKiem = new System.Windows.Forms.Button();
            this.panelLoaiHang.SuspendLayout();
            this.panelMatHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMatHang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLoaiHang)).BeginInit();
            this.panelTimKiemMH.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLoaiHang
            // 
            this.panelLoaiHang.Controls.Add(this.btnLHHuyTimKiem);
            this.panelLoaiHang.Controls.Add(this.txtLHTimKiemLH);
            this.panelLoaiHang.Controls.Add(this.btnLHHuy);
            this.panelLoaiHang.Controls.Add(this.btnLHLuu);
            this.panelLoaiHang.Controls.Add(this.btnLHTimKiem);
            this.panelLoaiHang.Controls.Add(this.btnLHXoaLH);
            this.panelLoaiHang.Controls.Add(this.btnLHSuaLH);
            this.panelLoaiHang.Controls.Add(this.btnLHThemLH);
            this.panelLoaiHang.Controls.Add(this.lbLHLoaiHang);
            this.panelLoaiHang.Controls.Add(this.txtLHLoaiHang);
            this.panelLoaiHang.Location = new System.Drawing.Point(12, 12);
            this.panelLoaiHang.Name = "panelLoaiHang";
            this.panelLoaiHang.Size = new System.Drawing.Size(139, 202);
            this.panelLoaiHang.TabIndex = 0;
            // 
            // txtLHTimKiemLH
            // 
            this.txtLHTimKiemLH.Location = new System.Drawing.Point(58, 145);
            this.txtLHTimKiemLH.Name = "txtLHTimKiemLH";
            this.txtLHTimKiemLH.Size = new System.Drawing.Size(78, 20);
            this.txtLHTimKiemLH.TabIndex = 8;
            // 
            // btnLHHuy
            // 
            this.btnLHHuy.Location = new System.Drawing.Point(72, 92);
            this.btnLHHuy.Name = "btnLHHuy";
            this.btnLHHuy.Size = new System.Drawing.Size(59, 23);
            this.btnLHHuy.TabIndex = 7;
            this.btnLHHuy.Text = "Hủy";
            this.btnLHHuy.UseVisualStyleBackColor = true;
            this.btnLHHuy.Click += new System.EventHandler(this.btnLHHuy_Click);
            // 
            // btnLHLuu
            // 
            this.btnLHLuu.Location = new System.Drawing.Point(72, 58);
            this.btnLHLuu.Name = "btnLHLuu";
            this.btnLHLuu.Size = new System.Drawing.Size(59, 23);
            this.btnLHLuu.TabIndex = 6;
            this.btnLHLuu.Text = "Lưu";
            this.btnLHLuu.UseVisualStyleBackColor = true;
            this.btnLHLuu.Click += new System.EventHandler(this.btnLHLuu_Click);
            // 
            // btnLHTimKiem
            // 
            this.btnLHTimKiem.Location = new System.Drawing.Point(6, 142);
            this.btnLHTimKiem.Name = "btnLHTimKiem";
            this.btnLHTimKiem.Size = new System.Drawing.Size(43, 23);
            this.btnLHTimKiem.TabIndex = 5;
            this.btnLHTimKiem.Text = "Tìm ";
            this.btnLHTimKiem.UseVisualStyleBackColor = true;
            this.btnLHTimKiem.Click += new System.EventHandler(this.btnLHTimKiem_Click);
            // 
            // btnLHXoaLH
            // 
            this.btnLHXoaLH.Location = new System.Drawing.Point(6, 106);
            this.btnLHXoaLH.Name = "btnLHXoaLH";
            this.btnLHXoaLH.Size = new System.Drawing.Size(54, 23);
            this.btnLHXoaLH.TabIndex = 4;
            this.btnLHXoaLH.Text = "Xóa ";
            this.btnLHXoaLH.UseVisualStyleBackColor = true;
            this.btnLHXoaLH.Click += new System.EventHandler(this.btnLHXoaLH_Click);
            // 
            // btnLHSuaLH
            // 
            this.btnLHSuaLH.Location = new System.Drawing.Point(6, 77);
            this.btnLHSuaLH.Name = "btnLHSuaLH";
            this.btnLHSuaLH.Size = new System.Drawing.Size(54, 23);
            this.btnLHSuaLH.TabIndex = 3;
            this.btnLHSuaLH.Text = "Sửa ";
            this.btnLHSuaLH.UseVisualStyleBackColor = true;
            this.btnLHSuaLH.Click += new System.EventHandler(this.btnLHSuaLH_Click);
            // 
            // btnLHThemLH
            // 
            this.btnLHThemLH.Location = new System.Drawing.Point(6, 48);
            this.btnLHThemLH.Name = "btnLHThemLH";
            this.btnLHThemLH.Size = new System.Drawing.Size(54, 23);
            this.btnLHThemLH.TabIndex = 2;
            this.btnLHThemLH.Text = "Thêm ";
            this.btnLHThemLH.UseVisualStyleBackColor = true;
            this.btnLHThemLH.Click += new System.EventHandler(this.btnLHThemLH_Click);
            // 
            // lbLHLoaiHang
            // 
            this.lbLHLoaiHang.AutoSize = true;
            this.lbLHLoaiHang.Location = new System.Drawing.Point(3, 16);
            this.lbLHLoaiHang.Name = "lbLHLoaiHang";
            this.lbLHLoaiHang.Size = new System.Drawing.Size(57, 13);
            this.lbLHLoaiHang.TabIndex = 1;
            this.lbLHLoaiHang.Text = "Loại hàng:";
            // 
            // txtLHLoaiHang
            // 
            this.txtLHLoaiHang.Location = new System.Drawing.Point(63, 13);
            this.txtLHLoaiHang.Name = "txtLHLoaiHang";
            this.txtLHLoaiHang.Size = new System.Drawing.Size(68, 20);
            this.txtLHLoaiHang.TabIndex = 0;
            // 
            // panelMatHang
            // 
            this.panelMatHang.Controls.Add(this.btnMHHuy);
            this.panelMatHang.Controls.Add(this.btnMHLuu);
            this.panelMatHang.Controls.Add(this.btnMHXoaMH);
            this.panelMatHang.Controls.Add(this.btnMHSuaMH);
            this.panelMatHang.Controls.Add(this.btnMHThemMH);
            this.panelMatHang.Controls.Add(this.comboBoxLoaiHang);
            this.panelMatHang.Controls.Add(this.DateTimePickerHanSD);
            this.panelMatHang.Controls.Add(this.lbMHHanSD);
            this.panelMatHang.Controls.Add(this.lbMHLoaiHang);
            this.panelMatHang.Controls.Add(this.txtMHNamSX);
            this.panelMatHang.Controls.Add(this.lbMHNamSX);
            this.panelMatHang.Controls.Add(this.txtMHTenCty);
            this.panelMatHang.Controls.Add(this.lbMHTenCty);
            this.panelMatHang.Controls.Add(this.txtMHTenMH);
            this.panelMatHang.Controls.Add(this.lbMHTenMH);
            this.panelMatHang.Controls.Add(this.txtMHMaMH);
            this.panelMatHang.Controls.Add(this.lbMHMaMH);
            this.panelMatHang.Location = new System.Drawing.Point(369, 12);
            this.panelMatHang.Name = "panelMatHang";
            this.panelMatHang.Size = new System.Drawing.Size(419, 202);
            this.panelMatHang.TabIndex = 1;
            // 
            // btnMHHuy
            // 
            this.btnMHHuy.Location = new System.Drawing.Point(353, 133);
            this.btnMHHuy.Name = "btnMHHuy";
            this.btnMHHuy.Size = new System.Drawing.Size(52, 23);
            this.btnMHHuy.TabIndex = 16;
            this.btnMHHuy.Text = "Hủy";
            this.btnMHHuy.UseVisualStyleBackColor = true;
            this.btnMHHuy.Click += new System.EventHandler(this.btnMHHuy_Click);
            // 
            // btnMHLuu
            // 
            this.btnMHLuu.Location = new System.Drawing.Point(277, 133);
            this.btnMHLuu.Name = "btnMHLuu";
            this.btnMHLuu.Size = new System.Drawing.Size(56, 23);
            this.btnMHLuu.TabIndex = 15;
            this.btnMHLuu.Text = "Lưu";
            this.btnMHLuu.UseVisualStyleBackColor = true;
            this.btnMHLuu.Click += new System.EventHandler(this.btnMHLuu_Click);
            // 
            // btnMHXoaMH
            // 
            this.btnMHXoaMH.Location = new System.Drawing.Point(156, 133);
            this.btnMHXoaMH.Name = "btnMHXoaMH";
            this.btnMHXoaMH.Size = new System.Drawing.Size(56, 23);
            this.btnMHXoaMH.TabIndex = 14;
            this.btnMHXoaMH.Text = "Xóa";
            this.btnMHXoaMH.UseVisualStyleBackColor = true;
            this.btnMHXoaMH.Click += new System.EventHandler(this.btnMHXoaMH_Click);
            // 
            // btnMHSuaMH
            // 
            this.btnMHSuaMH.Location = new System.Drawing.Point(80, 133);
            this.btnMHSuaMH.Name = "btnMHSuaMH";
            this.btnMHSuaMH.Size = new System.Drawing.Size(56, 23);
            this.btnMHSuaMH.TabIndex = 13;
            this.btnMHSuaMH.Text = "Sửa ";
            this.btnMHSuaMH.UseVisualStyleBackColor = true;
            this.btnMHSuaMH.Click += new System.EventHandler(this.btnMHSuaMH_Click);
            // 
            // btnMHThemMH
            // 
            this.btnMHThemMH.Location = new System.Drawing.Point(7, 133);
            this.btnMHThemMH.Name = "btnMHThemMH";
            this.btnMHThemMH.Size = new System.Drawing.Size(54, 23);
            this.btnMHThemMH.TabIndex = 5;
            this.btnMHThemMH.Text = "Thêm ";
            this.btnMHThemMH.UseVisualStyleBackColor = true;
            this.btnMHThemMH.Click += new System.EventHandler(this.btnMHThemMH_Click);
            // 
            // comboBoxLoaiHang
            // 
            this.comboBoxLoaiHang.FormattingEnabled = true;
            this.comboBoxLoaiHang.Location = new System.Drawing.Point(301, 12);
            this.comboBoxLoaiHang.Name = "comboBoxLoaiHang";
            this.comboBoxLoaiHang.Size = new System.Drawing.Size(104, 21);
            this.comboBoxLoaiHang.TabIndex = 12;
            this.comboBoxLoaiHang.DropDown += new System.EventHandler(this.comboBoxLoaiHang_DropDown);
            // 
            // DateTimePickerHanSD
            // 
            this.DateTimePickerHanSD.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateTimePickerHanSD.Location = new System.Drawing.Point(305, 57);
            this.DateTimePickerHanSD.Name = "DateTimePickerHanSD";
            this.DateTimePickerHanSD.Size = new System.Drawing.Size(100, 20);
            this.DateTimePickerHanSD.TabIndex = 11;
            this.DateTimePickerHanSD.Value = new System.DateTime(2020, 12, 8, 3, 3, 47, 0);
            // 
            // lbMHHanSD
            // 
            this.lbMHHanSD.AutoSize = true;
            this.lbMHHanSD.Location = new System.Drawing.Point(224, 58);
            this.lbMHHanSD.Name = "lbMHHanSD";
            this.lbMHHanSD.Size = new System.Drawing.Size(71, 13);
            this.lbMHHanSD.TabIndex = 10;
            this.lbMHHanSD.Text = "Hạn sử dụng:";
            // 
            // lbMHLoaiHang
            // 
            this.lbMHLoaiHang.AutoSize = true;
            this.lbMHLoaiHang.Location = new System.Drawing.Point(238, 15);
            this.lbMHLoaiHang.Name = "lbMHLoaiHang";
            this.lbMHLoaiHang.Size = new System.Drawing.Size(57, 13);
            this.lbMHLoaiHang.TabIndex = 8;
            this.lbMHLoaiHang.Text = "Loại hàng:";
            // 
            // txtMHNamSX
            // 
            this.txtMHNamSX.Location = new System.Drawing.Point(305, 94);
            this.txtMHNamSX.Name = "txtMHNamSX";
            this.txtMHNamSX.Size = new System.Drawing.Size(100, 20);
            this.txtMHNamSX.TabIndex = 7;
            this.txtMHNamSX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMHNamSX_KeyPress);
            // 
            // lbMHNamSX
            // 
            this.lbMHNamSX.AutoSize = true;
            this.lbMHNamSX.Location = new System.Drawing.Point(220, 98);
            this.lbMHNamSX.Name = "lbMHNamSX";
            this.lbMHNamSX.Size = new System.Drawing.Size(75, 13);
            this.lbMHNamSX.TabIndex = 6;
            this.lbMHNamSX.Text = "Năm sản xuất:";
            // 
            // txtMHTenCty
            // 
            this.txtMHTenCty.Location = new System.Drawing.Point(94, 95);
            this.txtMHTenCty.Name = "txtMHTenCty";
            this.txtMHTenCty.Size = new System.Drawing.Size(100, 20);
            this.txtMHTenCty.TabIndex = 5;
            // 
            // lbMHTenCty
            // 
            this.lbMHTenCty.AutoSize = true;
            this.lbMHTenCty.Location = new System.Drawing.Point(21, 98);
            this.lbMHTenCty.Name = "lbMHTenCty";
            this.lbMHTenCty.Size = new System.Drawing.Size(67, 13);
            this.lbMHTenCty.TabIndex = 4;
            this.lbMHTenCty.Text = "Tên công ty:";
            // 
            // txtMHTenMH
            // 
            this.txtMHTenMH.Location = new System.Drawing.Point(94, 55);
            this.txtMHTenMH.Name = "txtMHTenMH";
            this.txtMHTenMH.Size = new System.Drawing.Size(100, 20);
            this.txtMHTenMH.TabIndex = 3;
            // 
            // lbMHTenMH
            // 
            this.lbMHTenMH.AutoSize = true;
            this.lbMHTenMH.Location = new System.Drawing.Point(12, 58);
            this.lbMHTenMH.Name = "lbMHTenMH";
            this.lbMHTenMH.Size = new System.Drawing.Size(76, 13);
            this.lbMHTenMH.TabIndex = 2;
            this.lbMHTenMH.Text = "Tên mặt hàng:";
            // 
            // txtMHMaMH
            // 
            this.txtMHMaMH.Location = new System.Drawing.Point(94, 14);
            this.txtMHMaMH.Name = "txtMHMaMH";
            this.txtMHMaMH.Size = new System.Drawing.Size(100, 20);
            this.txtMHMaMH.TabIndex = 1;
            // 
            // lbMHMaMH
            // 
            this.lbMHMaMH.AutoSize = true;
            this.lbMHMaMH.Location = new System.Drawing.Point(16, 17);
            this.lbMHMaMH.Name = "lbMHMaMH";
            this.lbMHMaMH.Size = new System.Drawing.Size(72, 13);
            this.lbMHMaMH.TabIndex = 0;
            this.lbMHMaMH.Text = "Mã mặt hàng:";
            // 
            // btnMHTimKiemMaMH
            // 
            this.btnMHTimKiemMaMH.Location = new System.Drawing.Point(30, 17);
            this.btnMHTimKiemMaMH.Name = "btnMHTimKiemMaMH";
            this.btnMHTimKiemMaMH.Size = new System.Drawing.Size(132, 23);
            this.btnMHTimKiemMaMH.TabIndex = 15;
            this.btnMHTimKiemMaMH.Text = "Tìm Kiếm Mã Mặt Hàng";
            this.btnMHTimKiemMaMH.UseVisualStyleBackColor = true;
            this.btnMHTimKiemMaMH.Click += new System.EventHandler(this.btnMHTimKiemMaMH_Click);
            // 
            // dataGridViewMatHang
            // 
            this.dataGridViewMatHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewMatHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMatHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnMHMaMH,
            this.ColumnMHTenMH,
            this.ColumnMHTenCty,
            this.ColumnMHLoaiHang,
            this.ColumnMHHanSD,
            this.ColumnMHNamSX});
            this.dataGridViewMatHang.Location = new System.Drawing.Point(167, 220);
            this.dataGridViewMatHang.Name = "dataGridViewMatHang";
            this.dataGridViewMatHang.Size = new System.Drawing.Size(621, 218);
            this.dataGridViewMatHang.TabIndex = 3;
            this.dataGridViewMatHang.SelectionChanged += new System.EventHandler(this.dataGridViewMatHang_SelectionChanged);
            // 
            // ColumnMHMaMH
            // 
            this.ColumnMHMaMH.DataPropertyName = "Mamathang";
            this.ColumnMHMaMH.HeaderText = "Mã mặt hàng";
            this.ColumnMHMaMH.Name = "ColumnMHMaMH";
            // 
            // ColumnMHTenMH
            // 
            this.ColumnMHTenMH.DataPropertyName = "Tenmathang";
            this.ColumnMHTenMH.HeaderText = "Tên mặt hàng";
            this.ColumnMHTenMH.Name = "ColumnMHTenMH";
            // 
            // ColumnMHTenCty
            // 
            this.ColumnMHTenCty.DataPropertyName = "Tencongty";
            this.ColumnMHTenCty.HeaderText = "Tên công ty";
            this.ColumnMHTenCty.Name = "ColumnMHTenCty";
            // 
            // ColumnMHLoaiHang
            // 
            this.ColumnMHLoaiHang.DataPropertyName = "Loaihang";
            this.ColumnMHLoaiHang.HeaderText = "Loại hàng";
            this.ColumnMHLoaiHang.Name = "ColumnMHLoaiHang";
            // 
            // ColumnMHHanSD
            // 
            this.ColumnMHHanSD.DataPropertyName = "Hansudung";
            this.ColumnMHHanSD.HeaderText = "Hạn sử dụng";
            this.ColumnMHHanSD.Name = "ColumnMHHanSD";
            // 
            // ColumnMHNamSX
            // 
            this.ColumnMHNamSX.DataPropertyName = "Namsanxuat";
            this.ColumnMHNamSX.HeaderText = "Năm sản xuất";
            this.ColumnMHNamSX.Name = "ColumnMHNamSX";
            // 
            // dataGridViewLoaiHang
            // 
            this.dataGridViewLoaiHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewLoaiHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLoaiHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnLHLoaiHang});
            this.dataGridViewLoaiHang.Location = new System.Drawing.Point(12, 220);
            this.dataGridViewLoaiHang.Name = "dataGridViewLoaiHang";
            this.dataGridViewLoaiHang.Size = new System.Drawing.Size(139, 218);
            this.dataGridViewLoaiHang.TabIndex = 2;
            this.dataGridViewLoaiHang.SelectionChanged += new System.EventHandler(this.dataGridViewLoaiHang_SelectionChanged);
            // 
            // ColumnLHLoaiHang
            // 
            this.ColumnLHLoaiHang.DataPropertyName = "LHLoaihang";
            this.ColumnLHLoaiHang.HeaderText = "Loại hàng";
            this.ColumnLHLoaiHang.Name = "ColumnLHLoaiHang";
            // 
            // panelTimKiemMH
            // 
            this.panelTimKiemMH.Controls.Add(this.btnMHHuyTimKiem);
            this.panelTimKiemMH.Controls.Add(this.btnMHTimKiemMaMH);
            this.panelTimKiemMH.Controls.Add(this.txtTKMaMH);
            this.panelTimKiemMH.Location = new System.Drawing.Point(167, 12);
            this.panelTimKiemMH.Name = "panelTimKiemMH";
            this.panelTimKiemMH.Size = new System.Drawing.Size(196, 202);
            this.panelTimKiemMH.TabIndex = 16;
            // 
            // btnMHHuyTimKiem
            // 
            this.btnMHHuyTimKiem.Location = new System.Drawing.Point(45, 118);
            this.btnMHHuyTimKiem.Name = "btnMHHuyTimKiem";
            this.btnMHHuyTimKiem.Size = new System.Drawing.Size(106, 23);
            this.btnMHHuyTimKiem.TabIndex = 19;
            this.btnMHHuyTimKiem.Text = "Hủy Tìm Kiếm";
            this.btnMHHuyTimKiem.UseVisualStyleBackColor = true;
            this.btnMHHuyTimKiem.Click += new System.EventHandler(this.btnMHHuyTimKiem_Click);
            // 
            // txtTKMaMH
            // 
            this.txtTKMaMH.Location = new System.Drawing.Point(45, 48);
            this.txtTKMaMH.Name = "txtTKMaMH";
            this.txtTKMaMH.Size = new System.Drawing.Size(97, 20);
            this.txtTKMaMH.TabIndex = 18;
            // 
            // btnLHHuyTimKiem
            // 
            this.btnLHHuyTimKiem.Location = new System.Drawing.Point(24, 171);
            this.btnLHHuyTimKiem.Name = "btnLHHuyTimKiem";
            this.btnLHHuyTimKiem.Size = new System.Drawing.Size(94, 23);
            this.btnLHHuyTimKiem.TabIndex = 9;
            this.btnLHHuyTimKiem.Text = "Hủy Tìm Kiếm";
            this.btnLHHuyTimKiem.UseVisualStyleBackColor = true;
            this.btnLHHuyTimKiem.Click += new System.EventHandler(this.btnLHHuyTimKiem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelTimKiemMH);
            this.Controls.Add(this.dataGridViewMatHang);
            this.Controls.Add(this.dataGridViewLoaiHang);
            this.Controls.Add(this.panelMatHang);
            this.Controls.Add(this.panelLoaiHang);
            this.Name = "Form1";
            this.Text = "QuanLyCuaHang";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelLoaiHang.ResumeLayout(false);
            this.panelLoaiHang.PerformLayout();
            this.panelMatHang.ResumeLayout(false);
            this.panelMatHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMatHang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLoaiHang)).EndInit();
            this.panelTimKiemMH.ResumeLayout(false);
            this.panelTimKiemMH.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLoaiHang;
        private System.Windows.Forms.Panel panelMatHang;
        private System.Windows.Forms.Button btnLHXoaLH;
        private System.Windows.Forms.Button btnLHSuaLH;
        private System.Windows.Forms.Button btnLHThemLH;
        private System.Windows.Forms.Label lbLHLoaiHang;
        private System.Windows.Forms.TextBox txtLHLoaiHang;
        private System.Windows.Forms.ComboBox comboBoxLoaiHang;
        private System.Windows.Forms.DateTimePicker DateTimePickerHanSD;
        private System.Windows.Forms.Label lbMHHanSD;
        private System.Windows.Forms.Label lbMHLoaiHang;
        private System.Windows.Forms.TextBox txtMHNamSX;
        private System.Windows.Forms.Label lbMHNamSX;
        private System.Windows.Forms.TextBox txtMHTenCty;
        private System.Windows.Forms.Label lbMHTenCty;
        private System.Windows.Forms.TextBox txtMHTenMH;
        private System.Windows.Forms.Label lbMHTenMH;
        private System.Windows.Forms.TextBox txtMHMaMH;
        private System.Windows.Forms.Label lbMHMaMH;
        private System.Windows.Forms.DataGridView dataGridViewMatHang;
        private System.Windows.Forms.DataGridView dataGridViewLoaiHang;
        private System.Windows.Forms.Button btnMHXoaMH;
        private System.Windows.Forms.Button btnMHSuaMH;
        private System.Windows.Forms.Button btnMHThemMH;
        private System.Windows.Forms.Button btnLHTimKiem;
        private System.Windows.Forms.Button btnMHTimKiemMaMH;
        private System.Windows.Forms.Button btnLHHuy;
        private System.Windows.Forms.Button btnLHLuu;
        private System.Windows.Forms.Button btnMHHuy;
        private System.Windows.Forms.Button btnMHLuu;
        private System.Windows.Forms.Panel panelTimKiemMH;
        private System.Windows.Forms.TextBox txtTKMaMH;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnLHLoaiHang;
        private System.Windows.Forms.TextBox txtLHTimKiemLH;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMHMaMH;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMHTenMH;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMHTenCty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMHLoaiHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMHHanSD;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMHNamSX;
        private System.Windows.Forms.Button btnMHHuyTimKiem;
        private System.Windows.Forms.Button btnLHHuyTimKiem;
    }
}

