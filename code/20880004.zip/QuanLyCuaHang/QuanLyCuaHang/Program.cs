﻿using System;

namespace QuanLyCuaHang
{
    class Program
    {
        // Thông tin học viên:
        // Họ và tên: Nguyễn Thiên Ân
        // MSSV: 20880004
        static void Main(string[] args)
        {
            XL_LuongChuongTrinh.BatDauChuongTrinh();
        }
    }
}
