﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLCH_20810025
{
    public struct KB_HangHoa
    {
        public string Mahang;
        public string Tenhang;
        public string CongtySX;
        public DateTime NamSX;
        public DateTime Hansudung;
        public string Loaihang;
    }

}
