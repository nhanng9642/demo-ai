class Category {
    public string id;
    public string name;

    public string toString() {
        return "Category " + id + ", name: " + name;
    }
}