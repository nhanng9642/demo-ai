﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace DoAn_NMLT_20880106
{
    public class Store
    {

        public static void KhoHang(ref ArrayList ArrayHH, ref ArrayList ArrayLH)
        {
            Show.HienThiHangHoa(ref ArrayHH,ref ArrayLH,"");
        }
    }
}
