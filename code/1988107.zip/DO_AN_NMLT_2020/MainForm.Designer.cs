﻿namespace DO_AN_NMLT_2020
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMaMH = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTenMH = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtHanDung = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCongTySX = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNamSX = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLoaiHang = new System.Windows.Forms.TextBox();
            this.btNhapMatHang = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.lsMatHang = new System.Windows.Forms.ListView();
            this.MaMH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TenMH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.HanDung = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CongTySX = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NamSX = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LoaiHang = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtTimKiemMH = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btXoaMatHang = new System.Windows.Forms.Button();
            this.btSuaMatHang = new System.Windows.Forms.Button();
            this.mặtHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loạiHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbMatHang = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTimKiemLH = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.lsLoaiHang = new System.Windows.Forms.ListView();
            this.MaLH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TenLH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btXoaLoaiHang = new System.Windows.Forms.Button();
            this.btSuaLoaiHang = new System.Windows.Forms.Button();
            this.txtTenLH = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMaLH = new System.Windows.Forms.TextBox();
            this.btNhapLoaiHang = new System.Windows.Forms.Button();
            this.tbMatHang.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMaMH
            // 
            this.txtMaMH.Location = new System.Drawing.Point(142, 38);
            this.txtMaMH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMaMH.Name = "txtMaMH";
            this.txtMaMH.Size = new System.Drawing.Size(148, 26);
            this.txtMaMH.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 41);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Mã mặt hàng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 97);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tên mặt hàng";
            // 
            // txtTenMH
            // 
            this.txtTenMH.Location = new System.Drawing.Point(142, 93);
            this.txtTenMH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTenMH.Name = "txtTenMH";
            this.txtTenMH.Size = new System.Drawing.Size(148, 26);
            this.txtTenMH.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 152);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Hạn dùng";
            // 
            // txtHanDung
            // 
            this.txtHanDung.Location = new System.Drawing.Point(142, 149);
            this.txtHanDung.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtHanDung.Name = "txtHanDung";
            this.txtHanDung.Size = new System.Drawing.Size(148, 26);
            this.txtHanDung.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 209);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Công ty sản xuất";
            // 
            // txtCongTySX
            // 
            this.txtCongTySX.Location = new System.Drawing.Point(142, 206);
            this.txtCongTySX.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtCongTySX.Name = "txtCongTySX";
            this.txtCongTySX.Size = new System.Drawing.Size(148, 26);
            this.txtCongTySX.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 264);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Năm sản xuất";
            // 
            // txtNamSX
            // 
            this.txtNamSX.Location = new System.Drawing.Point(142, 261);
            this.txtNamSX.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNamSX.Name = "txtNamSX";
            this.txtNamSX.Size = new System.Drawing.Size(148, 26);
            this.txtNamSX.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 320);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Loại hàng";
            // 
            // txtLoaiHang
            // 
            this.txtLoaiHang.Location = new System.Drawing.Point(142, 317);
            this.txtLoaiHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLoaiHang.Name = "txtLoaiHang";
            this.txtLoaiHang.Size = new System.Drawing.Size(148, 26);
            this.txtLoaiHang.TabIndex = 11;
            // 
            // btNhapMatHang
            // 
            this.btNhapMatHang.Location = new System.Drawing.Point(7, 381);
            this.btNhapMatHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btNhapMatHang.Name = "btNhapMatHang";
            this.btNhapMatHang.Size = new System.Drawing.Size(147, 35);
            this.btNhapMatHang.TabIndex = 12;
            this.btNhapMatHang.Text = "Nhập";
            this.btNhapMatHang.UseVisualStyleBackColor = true;
            this.btNhapMatHang.Click += new System.EventHandler(this.btNhapMatHang_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(352, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "Danh sách mặt hàng";
            // 
            // lsMatHang
            // 
            this.lsMatHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.MaMH,
            this.TenMH,
            this.HanDung,
            this.CongTySX,
            this.NamSX,
            this.LoaiHang});
            this.lsMatHang.GridLines = true;
            this.lsMatHang.HideSelection = false;
            this.lsMatHang.Location = new System.Drawing.Point(356, 93);
            this.lsMatHang.Name = "lsMatHang";
            this.lsMatHang.Size = new System.Drawing.Size(1181, 321);
            this.lsMatHang.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.lsMatHang.TabIndex = 15;
            this.lsMatHang.UseCompatibleStateImageBehavior = false;
            this.lsMatHang.View = System.Windows.Forms.View.Details;
            // 
            // MaMH
            // 
            this.MaMH.Text = "Mã mặt hàng";
            this.MaMH.Width = 130;
            // 
            // TenMH
            // 
            this.TenMH.Text = "Tên mặt hàng";
            this.TenMH.Width = 130;
            // 
            // HanDung
            // 
            this.HanDung.Text = "Hạn dùng";
            this.HanDung.Width = 130;
            // 
            // CongTySX
            // 
            this.CongTySX.Text = "Công ty sản xuất";
            this.CongTySX.Width = 130;
            // 
            // NamSX
            // 
            this.NamSX.Text = "Năm sản xuất";
            this.NamSX.Width = 130;
            // 
            // LoaiHang
            // 
            this.LoaiHang.Text = "Loại hàng";
            this.LoaiHang.Width = 130;
            // 
            // txtTimKiemMH
            // 
            this.txtTimKiemMH.Location = new System.Drawing.Point(724, 41);
            this.txtTimKiemMH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTimKiemMH.Name = "txtTimKiemMH";
            this.txtTimKiemMH.Size = new System.Drawing.Size(811, 26);
            this.txtTimKiemMH.TabIndex = 16;
            this.txtTimKiemMH.TextChanged += new System.EventHandler(this.txtTimKiemMH_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(574, 43);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(142, 20);
            this.label8.TabIndex = 17;
            this.label8.Text = "Tìm kiếm mặt hàng";
            // 
            // btXoaMatHang
            // 
            this.btXoaMatHang.Location = new System.Drawing.Point(163, 426);
            this.btXoaMatHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btXoaMatHang.Name = "btXoaMatHang";
            this.btXoaMatHang.Size = new System.Drawing.Size(147, 35);
            this.btXoaMatHang.TabIndex = 18;
            this.btXoaMatHang.Text = "Xóa";
            this.btXoaMatHang.UseVisualStyleBackColor = true;
            this.btXoaMatHang.Click += new System.EventHandler(this.btXoaMatHang_Click);
            // 
            // btSuaMatHang
            // 
            this.btSuaMatHang.Location = new System.Drawing.Point(163, 381);
            this.btSuaMatHang.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btSuaMatHang.Name = "btSuaMatHang";
            this.btSuaMatHang.Size = new System.Drawing.Size(147, 35);
            this.btSuaMatHang.TabIndex = 19;
            this.btSuaMatHang.Text = "Sửa";
            this.btSuaMatHang.UseVisualStyleBackColor = true;
            this.btSuaMatHang.Click += new System.EventHandler(this.btSuaMatHang_Click);
            // 
            // mặtHàngToolStripMenuItem
            // 
            this.mặtHàngToolStripMenuItem.Name = "mặtHàngToolStripMenuItem";
            this.mặtHàngToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // loạiHàngToolStripMenuItem
            // 
            this.loạiHàngToolStripMenuItem.Name = "loạiHàngToolStripMenuItem";
            this.loạiHàngToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // tbMatHang
            // 
            this.tbMatHang.Controls.Add(this.tabPage1);
            this.tbMatHang.Controls.Add(this.tabPage2);
            this.tbMatHang.Location = new System.Drawing.Point(12, 13);
            this.tbMatHang.Name = "tbMatHang";
            this.tbMatHang.SelectedIndex = 0;
            this.tbMatHang.Size = new System.Drawing.Size(1551, 664);
            this.tbMatHang.TabIndex = 20;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.btSuaMatHang);
            this.tabPage1.Controls.Add(this.txtMaMH);
            this.tabPage1.Controls.Add(this.btXoaMatHang);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtTimKiemMH);
            this.tabPage1.Controls.Add(this.txtTenMH);
            this.tabPage1.Controls.Add(this.lsMatHang);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.txtHanDung);
            this.tabPage1.Controls.Add(this.btNhapMatHang);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtLoaiHang);
            this.tabPage1.Controls.Add(this.txtCongTySX);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtNamSX);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1543, 631);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Quản lí mặt hàng";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.txtTimKiemLH);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.lsLoaiHang);
            this.tabPage2.Controls.Add(this.btXoaLoaiHang);
            this.tabPage2.Controls.Add(this.btSuaLoaiHang);
            this.tabPage2.Controls.Add(this.txtTenLH);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txtMaLH);
            this.tabPage2.Controls.Add(this.btNhapLoaiHang);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1543, 631);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Quản lí loại hàng";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(588, 35);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 20);
            this.label11.TabIndex = 20;
            this.label11.Text = "Tìm kiếm loại hàng";
            // 
            // txtTimKiemLH
            // 
            this.txtTimKiemLH.Location = new System.Drawing.Point(738, 33);
            this.txtTimKiemLH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTimKiemLH.Name = "txtTimKiemLH";
            this.txtTimKiemLH.Size = new System.Drawing.Size(811, 26);
            this.txtTimKiemLH.TabIndex = 19;
            this.txtTimKiemLH.TextChanged += new System.EventHandler(this.txtTimKiemLH_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(349, 35);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(154, 20);
            this.label12.TabIndex = 18;
            this.label12.Text = "Danh sách loại hàng";
            // 
            // lsLoaiHang
            // 
            this.lsLoaiHang.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.MaLH,
            this.TenLH});
            this.lsLoaiHang.GridLines = true;
            this.lsLoaiHang.HideSelection = false;
            this.lsLoaiHang.Location = new System.Drawing.Point(353, 96);
            this.lsLoaiHang.Name = "lsLoaiHang";
            this.lsLoaiHang.Size = new System.Drawing.Size(1184, 274);
            this.lsLoaiHang.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.lsLoaiHang.TabIndex = 16;
            this.lsLoaiHang.UseCompatibleStateImageBehavior = false;
            this.lsLoaiHang.View = System.Windows.Forms.View.Details;
            // 
            // MaLH
            // 
            this.MaLH.Text = "Mã loại hàng";
            this.MaLH.Width = 130;
            // 
            // TenLH
            // 
            this.TenLH.Text = "Tên loại hàng";
            this.TenLH.Width = 130;
            // 
            // btXoaLoaiHang
            // 
            this.btXoaLoaiHang.Location = new System.Drawing.Point(153, 241);
            this.btXoaLoaiHang.Name = "btXoaLoaiHang";
            this.btXoaLoaiHang.Size = new System.Drawing.Size(149, 32);
            this.btXoaLoaiHang.TabIndex = 6;
            this.btXoaLoaiHang.Text = "Xóa";
            this.btXoaLoaiHang.UseVisualStyleBackColor = true;
            this.btXoaLoaiHang.Click += new System.EventHandler(this.btXoaLoaiHang_Click);
            // 
            // btSuaLoaiHang
            // 
            this.btSuaLoaiHang.Location = new System.Drawing.Point(153, 173);
            this.btSuaLoaiHang.Name = "btSuaLoaiHang";
            this.btSuaLoaiHang.Size = new System.Drawing.Size(149, 32);
            this.btSuaLoaiHang.TabIndex = 5;
            this.btSuaLoaiHang.Text = "Sửa";
            this.btSuaLoaiHang.UseVisualStyleBackColor = true;
            this.btSuaLoaiHang.Click += new System.EventHandler(this.btSuaLoaiHang_Click);
            // 
            // txtTenLH
            // 
            this.txtTenLH.Location = new System.Drawing.Point(137, 95);
            this.txtTenLH.Name = "txtTenLH";
            this.txtTenLH.Size = new System.Drawing.Size(165, 26);
            this.txtTenLH.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 98);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 20);
            this.label10.TabIndex = 3;
            this.label10.Text = "Tên loại hàng";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(11, 39);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 20);
            this.label9.TabIndex = 2;
            this.label9.Text = "Mã loại hàng";
            // 
            // txtMaLH
            // 
            this.txtMaLH.Location = new System.Drawing.Point(137, 36);
            this.txtMaLH.Name = "txtMaLH";
            this.txtMaLH.Size = new System.Drawing.Size(165, 26);
            this.txtMaLH.TabIndex = 1;
            // 
            // btNhapLoaiHang
            // 
            this.btNhapLoaiHang.Location = new System.Drawing.Point(10, 173);
            this.btNhapLoaiHang.Name = "btNhapLoaiHang";
            this.btNhapLoaiHang.Size = new System.Drawing.Size(137, 32);
            this.btNhapLoaiHang.TabIndex = 0;
            this.btNhapLoaiHang.Text = "Nhập";
            this.btNhapLoaiHang.UseVisualStyleBackColor = true;
            this.btNhapLoaiHang.Click += new System.EventHandler(this.btNhapLoaiHang_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1575, 689);
            this.Controls.Add(this.tbMatHang);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MainForm";
            this.Text = "Đồ án NMLT 2020 - 1988107";
            this.tbMatHang.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTenMH;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtHanDung;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCongTySX;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNamSX;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtLoaiHang;
        private System.Windows.Forms.Button btNhapMatHang;
        private System.Windows.Forms.TextBox txtMaMH;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListView lsMatHang;
        private System.Windows.Forms.ColumnHeader MaMH;
        private System.Windows.Forms.ColumnHeader TenMH;
        private System.Windows.Forms.ColumnHeader HanDung;
        private System.Windows.Forms.ColumnHeader CongTySX;
        private System.Windows.Forms.ColumnHeader NamSX;
        private System.Windows.Forms.ColumnHeader LoaiHang;
        private System.Windows.Forms.TextBox txtTimKiemMH;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btXoaMatHang;
        private System.Windows.Forms.Button btSuaMatHang;
        private System.Windows.Forms.ToolStripMenuItem mặtHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loạiHàngToolStripMenuItem;
        private System.Windows.Forms.TabControl tbMatHang;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtTenLH;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtMaLH;
        private System.Windows.Forms.Button btNhapLoaiHang;
        private System.Windows.Forms.Button btXoaLoaiHang;
        private System.Windows.Forms.Button btSuaLoaiHang;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtTimKiemLH;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListView lsLoaiHang;
        private System.Windows.Forms.ColumnHeader MaLH;
        private System.Windows.Forms.ColumnHeader TenLH;
    }
}

