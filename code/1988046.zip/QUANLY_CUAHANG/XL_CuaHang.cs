﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QUANLY_CUAHANG
{
    class MatHang
    {
        public string MaHang;
        public string TenHang;
        public DateTime  HanDung;
        public string CongTySX;
        public int NamSX;
        public string LoaiHang;
    }
    class LoaiHang
    {
        public string MaLoaiHang;
        public string TenLoaiHang;
    }

}
