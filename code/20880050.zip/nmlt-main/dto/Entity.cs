namespace product_management.dto
{
    public class Entity
    {
        public int Id;

        public string Name;
    }
}